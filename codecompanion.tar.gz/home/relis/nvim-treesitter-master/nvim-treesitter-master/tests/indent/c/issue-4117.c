int main(){
    if(1){
    } 
    else {
    }
}
