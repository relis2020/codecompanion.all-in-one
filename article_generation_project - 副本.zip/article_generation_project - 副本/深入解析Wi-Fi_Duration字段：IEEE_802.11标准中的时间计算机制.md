# 深入解析Wi-Fi Duration字段：IEEE 802.11标准中的时间计算机制

## 引言

在无线局域网（WLAN）技术中，介质访问控制（MAC）层的协调与同步是实现高效数据传输的关键。IEEE 802.11标准通过**Duration字段**这一精巧的设计，实现了对无线信道占用时间的精确管理。Duration字段存在于多种802.11帧中，其值直接决定了其他站点应当保持静默的时间长度，从而避免冲突并保证关键帧交换序列的完整性。本文将深入探讨Duration字段的计算方法，涵盖RTS/CTS机制、各种PPDU类型的持续时间约束、HT混合格式的特殊处理，以及NAV更新机制等核心内容，为网络工程师和协议开发人员提供全面的技术参考。

## 核心概念与基础原理

### Duration字段的作用与意义

Duration/ID字段是802.11帧头中的一个重要组成部分，长度为2字节。其主要功能包括：
- **网络分配向量（NAV）设置**：通过指示信道将被占用的时间长度，实现虚拟载波侦听
- **传输机会（TXOP）保护**：确保帧交换序列不会被其他站点中断
- **节能机制**：帮助站点确定何时可以进入睡眠状态

### 基本计算原则

Duration字段的计算遵循一个基本原则：它必须覆盖当前帧传输时间、所有预期的响应帧传输时间以及其间所有的帧间间隔。具体计算需要考虑帧类型、物理层参数、协议约束等多个因素。

## RTS/CTS机制中的Duration计算

### 机制概述

请求发送/清除发送（RTS/CTS）机制是802.11协议中解决隐藏节点问题的重要方案。在此机制中，Duration字段的计算需要确保整个交换序列的完整性。

### 计算细节

根据IEEE 802.11-2024标准，当`dot11TXOPDurationRTSThreshold`参数存在且不等于1023时，非AP HE STA（高性能站点）需要使用RTS/CTS交换（遵循26.2.1节规定）。此时，Duration字段必须覆盖：

- RTS帧传输时间
- CTS帧传输时间
- 数据帧传输时间
- 确认帧（ACK）传输时间
- 所有相关的SIFS（短帧间间隔）时间

具体计算公式为：
```
Duration = T_RTS + T_CTS + T_Data + T_ACK + 3 × SIFS
```

其中各个时间成分需要通过物理层管理实体接口（PLME）的原语进行精确计算。

## 各种PPDU类型的持续时间约束

### 约束机制概述

802.11标准对不同类型的物理层协议数据单元（PPDU）设置了最大持续时间限制（aPPDUMaxTime），这些限制因PPDU类型和物理层特性而异。

### 具体约束规范

- **HT PPDU**：持续时间不得超过Table 19-25中定义的aPPDUMaxTime值
- **VHT PPDU**：特别是VHT MU（多用户）PPDU，需要根据CH_BANDWIDTH参数匹配相应的aAPEPMaxLength约束
- **HE PPDU**：限制参见Table 27-61中的aPPDUMaxTime定义
- **S1G PPDU**：遵循Table 23-41的约束条件
- **DMG PPDU**：参见Table 20-30中的规定

实际传输前，站点必须通过`PLME-TXTIME.confirm`原语确定PPDU的实际持续时间，并确保其不超过相应类型的最大时间限制。

## HT混合格式PPDU的特殊处理

### 背景与需求

HT混合格式PPDU的设计允许传统（非HT）STA与HT STA共存于同一网络中。为了确保向后兼容，需要特殊的Duration计算机制。

### L_LENGTH和L_DATARATE参数

在HT混合格式PPDU中，`L_LENGTH`和`L_DATARATE`参数共同决定了非HT STA应当保持静默的时间长度：

- `L_DATARATE`参数固定为6 Mb/s
- `L_LENGTH`参数通过公式(10-17)计算，其值表示在非HT前导码之后的HT PPDU剩余持续时间

这种机制确保了传统设备能够正确解析Duration信息并避免在HT传输期间访问信道。

## 时间计算中的关键参数与公式

### 基本时间参数

Duration计算依赖于多个关键时间参数：
- `aSIFSTime`：短帧间间隔时间
- `aSlotTime`：时隙时间
- `DIFS`：分布式协调功能帧间间隔
- `EIFS`：扩展帧间间隔

### EIFS计算细节

EIFS的计算公式为：
```
EIFS = aSIFSTime + AckTxTime + DIFS
```

其中AckTxTime的估计取决于引发EIFS的PPDU的调制方式：
- 对于DSSS调制，1 Mb/s速率对应的AckTxTime为304μs
- 长前导码下≥2 Mb/s时为248μs
- 短前导码下相应值有所不同

### 公式参考

标准中提供了多个关键计算公式：
- 公式(10-10)和(10-11)涉及基本时间计算
- 公式(10-17)用于HT混合格式的L_LENGTH计算
- 各种PPDU类型的持续时间计算遵循各自的物理层特性

## NAV更新与Duration字段处理

### NAV更新机制

网络分配向量（NAV）是802.11MAC层实现虚拟载波侦听的关键机制。当接收到Duration字段值小于32768的帧时，站点会根据帧类型和内容更新NAV：

- **RTS帧**：设置NAV_RTSCANCELABLE标志为true
- **其他帧类型**：根据具体条件决定是否更新NAV

### 处理流程

NAV更新遵循标准中10.3.2.4、10.23.3.4等章节定义的流程，主要步骤包括：
1. 解析接收到的Duration字段值
2. 根据帧类型和子类型确定处理规则
3. 结合RXVECTOR参数（如TXOP_DURATION）更新NAV计时器
4. 设置相应的NAV标志位

## 实际应用与实施考虑

### 实现挑战

在实际设备中实现精确的Duration计算面临多个挑战：
- 不同PPDU类型的特性差异
- 各种调制和编码方案的影响
- 物理层参数的变化和适配
- 与传统设备的兼容性要求

### 优化策略

为了优化Duration计算的准确性和效率，可以考虑以下策略：
- 采用预计算和查表结合的方式减少实时计算开销
- 根据网络条件动态调整参数
- 实施适当的容错机制处理边界情况

## 总结

Duration字段的计算是802.11协议中一个复杂但至关重要的环节，它直接影响到无线网络的性能和可靠性。本文详细探讨了各种场景下的Duration计算机制，包括RTS/CTS交换、不同PPDU类型的持续时间约束、HT混合格式的特殊处理，以及NAV更新流程。

准确计算Duration字段需要综合考虑帧类型、物理层参数、协议约束等多个因素。实施人员必须深入理解相关标准条款，特别是IEEE 802.11-2024中第10章、第19章、第26章等关键章节的内容。

随着Wi-Fi技术的持续演进，特别是WLAN sensing等新功能的引入，Duration字段的计算可能会面临新的需求和挑战。持续关注标准发展和技术演进，对于设计和实现高质量的WLAN产品至关重要。

## 参考文献

1. IEEE Std 802.11-2024, IEEE Standard for Information Technology—Telecommunications and information exchange between systems—Local and metropolitan area networks—Specific requirements - Part 11: Wireless LAN Medium Access Control (MAC) and Physical Layer (PHY) Specifications
2. IEEE 802.11-2020, Part 11: Wireless LAN Medium Access Control (MAC) and Physical Layer (PHY) Specifications
3. 相关技术白皮书和实施指南