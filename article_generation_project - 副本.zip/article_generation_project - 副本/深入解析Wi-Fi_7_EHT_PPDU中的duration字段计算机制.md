# 深入解析Wi-Fi 7 EHT PPDU中的duration字段计算机制

## 引言

在Wi-Fi 7（EHT，Extremely High Throughput）标准中，duration字段的精确计算对于无线通信系统的性能优化和资源调度至关重要。该字段不仅决定了数据传输的时间长度，还直接影响多用户调度、功率控制以及信道利用率等关键性能指标。本文基于IEEE 802.11be标准文档，系统性地解析EHT PPDU（Physical Protocol Data Unit）中duration字段的计算方法，涵盖TXTIME参数、符号数量确定、预编码填充因子调整等核心技术要素。通过深入理解这些计算机制，工程师能够更好地设计和优化下一代Wi-Fi系统。

## 核心内容

### 1. TXTIME参数的基础计算框架

EHT PPDU的duration字段主要通过TXTIME参数来表征，其计算遵循公式（36-110）：

$$
\mathrm{TXTIME} = 20 + T_{\mathrm{EHT-PREAMBLE}} + N_{SYM}T_{SYM} + T_{PE} + \mathrm{SignalExtension}
$$

其中：
- **20微秒**：代表基本帧间隔和固定开销
- **$T_{\mathrm{EHT-PREAMBLE}}$**：前导码持续时间，由公式（36-97）定义
- **$N_{SYM}T_{SYM}$**：数据符号总时间，$N_{SYM}$为OFDM符号数量，$T_{SYM}$为符号周期
- **$T_{PE}$**：Packet Extension字段持续时间
- **SignalExtension**：信号扩展时间，取值参考表27-54中的aSignalExtension定义

### 2. 数据符号数量$N_{SYM}$的确定

$N_{SYM}$的计算涉及多个参数，主要包括：
- **$N_{SYM,init}$**：初始符号数量，由公式（36-51）计算
- **$N_{DBPS,u}$**：每用户每符号数据比特数，参考表36-23
- **$N_{DBPS,last,u}$**：最后符号的数据比特数，BCC编码使用公式（36-61），LDPC编码使用公式（36-60）
- **$N_{DBPS,last,init,u}$**：最后符号初始比特数，由公式（36-52）确定

对于多用户EHT MU PPDU，总数据符号数量需要考虑所有用户的空间流分配和编码参数。

### 3. 预编码填充因子$a$的调整机制

预FEC填充因子$a$（取值范围1-4）的调整对duration计算有重要影响，具体调整规则为：

$$
a_{RX,u} = \left\{ \begin{array}{ll}
4, & \text{if用户}u\text{使用LDPC编码，EHT-SIG中LDPC Extra Symbol Segment字段为1且}a=1 \\
a-1, & \text{if用户}u\text{使用LDPC编码，EHT-SIG中LDPC Extra Symbol Segment字段为1且}a>1 \\
a, & \text{其他情况}
\end{array} \right.
$$

这一调整机制确保了LDPC编码下的符号对齐和传输效率优化。

### 4. 关键时间参数定义

EHT PPDU duration计算依赖以下基础时间参数：

| 参数 | 值 | 描述 |
|------|-----|------|
| $T_{L-STF}$ | 8 μs | 非HT短训练字段持续时间 |
| $T_{L-LTF}$ | 8 μs | 非HT长训练字段持续时间 |
| $T_{L-SIG}$ | 4 μs | 非HT信号字段持续时间 |
| $\Delta F_{Pre-EHT}$ | 312.5 kHz | 前EHT调制子载波间隔 |
| $\Delta F_{EHT}$ | 78.125 kHz | EHT数据字段子载波间隔 |
| $T_{DFT,Pre-EHT}$ | 3.2 μs | 前EHT调制IDFT/DFT周期 |
| $T_{DFT,EHT}$ | 12.8 μs | EHT数据字段IDFT/DFT周期 |

### 5. Packet Extension字段的特殊处理

EHT标准支持$0\mu s$、$4\mu s$、$8\mu s$、$12\mu s$、$16\mu s$或$20\mu s$的PE字段持续时间。其中$20\mu s$的PE仅在以下情况允许：
- EHT MU PPDU中至少有一个参与STA使用4096-QAM调制
- 320 MHz EHT MU PPDU中分配的RU或MRU尺寸大于$2\times996$
- EHT TB PPDU传输

### 6. 多用户场景的特殊考虑

在多用户传输中，duration计算还需考虑：
- **NRU**：占用RU或MRU的数量
- **$N_{user,r}$**：第r个占用RU/MRU中的用户总数
- **$N_{user,total}$**：所有RU/MRU中的总用户数
- **$M_{r,u}$**：RU r中用户u之前的所有用户空间流数之和

这些参数影响了前导码结构和信号字段的设计，进而影响总体duration值。

### 7. 响应PPDU的duration对齐机制

当使用SRS控制字段时，响应PPDU的duration必须等于SRS控制子字段中PPDU响应持续时间子字段指定的值。响应PPDU可以采用non-HT（重复）PPDU、HE SU PPDU或寻址到单个STA的EHT MU PPDU格式。

## 总结

EHT PPDU duration字段的计算是一个复杂但精确的过程，涉及TXTIME参数、符号数量、预编码填充因子、基础时间参数和Packet Extension等多个技术要素。通过公式（36-110）的基础框架，结合用户特定的编码方案、调制方式和资源分配参数，系统能够准确计算出传输所需的时间长度。

这种精确的duration计算机制为Wi-Fi 7系统提供了关键的时间同步和资源调度基础，确保了多用户MIMO传输的高效性和可靠性。随着802.11be标准的进一步完善，duration计算算法将继续演进，为下一代无线通信系统提供更优的性能保障。

对于无线系统工程师而言，深入理解这些计算原理不仅有助于系统设计和性能优化，还能为故障排查和网络优化提供重要的技术依据。在实际应用中，建议结合具体硬件平台和软件实现，验证和优化duration计算算法，以达到最佳的系统性能。