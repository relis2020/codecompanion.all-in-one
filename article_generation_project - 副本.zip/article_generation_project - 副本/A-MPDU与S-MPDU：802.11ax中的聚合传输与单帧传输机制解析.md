# A-MPDU与S-MPDU：802.11ax中的聚合传输与单帧传输机制解析

## 引言

在现代无线局域网（WLAN）技术中，高效的数据传输机制对提升网络性能至关重要。IEEE 802.11标准从最初的单帧传输发展到支持帧聚合技术，显著提高了信道利用率和吞吐量。在802.11ax及后续标准中，**A-MPDU**（Aggregated MAC Protocol Data Unit）和**S-MPDU**（Single MAC Protocol Data Unit）作为两种关键的协议数据单元格式，各自承担着不同的角色并满足特定的通信需求。本文将深入探讨这两种传输机制的技术特点、区别及其协同工作方式，解析为什么在高吞吐量的A-MPDU存在的同时，S-MPDU仍然不可或缺。

## 技术背景：MPDU聚合演进

### MPDU基础概念
MAC Protocol Data Unit（MPDU）是802.11协议中MAC层的基本数据传输单位。传统的MPDU传输方式在每个传输机会（TXOP）中只能发送一个数据帧，导致大量协议开销（如前导码、帧间隔等），降低了信道利用率。

### 帧聚合技术的发展
为提高效率，802.11n标准引入了帧聚合技术，主要包括：
- **A-MSDU**（Aggregated MAC Service Data Unit）：在MAC层服务数据单元级别聚合多个数据包
- **A-MPDU**（Aggregated MAC Protocol Data Unit）：在MAC层协议数据单元级别聚合多个帧

802.11ax进一步优化了这些机制，并明确了A-MPDU和S-MPDU的应用场景和规则。

## A-MPDU：高吞吐量聚合传输

### 技术原理与结构
A-MPDU通过将多个MPDU子帧聚合到一个物理层协议数据单元（PPDU）中传输，显著减少了协议开销。每个A-MPDU包含：
- 一个A-MPDU前缀
- 多个MPDU子帧（每个子帧包含帧头、有效载荷和FCS）
- 一个A-MPDU后缀

### 传输规则与限制
根据IEEE 802.11ax-2021标准，A-MPDU的构建和传输需遵循严格规则：

```plaintext
function can_aggregate_to_ampdu(mpdu):
    if mpdu.is_group_addressed:          // 组播地址帧
        return false
    if mpdu.is_management_frame:         // 管理帧
        return false
    if mpdu.requires_immediate_ack:      // 需要立即确认的帧
        return false
    if not ba_agreement_exists:          // 无块确认协议
        return false
    if txop_limit == 0:                  // TXOP限制为0
        return false
    return true
```

A-MPDU必须承载于HE SU PPDU、HE ER SU PPDU或HE MU PPDU中，且必须包含至少一个与主访问类别（AC）对应的TID（流量标识符）的MPDU。

### 性能优势
A-MPDU的主要优势包括：
- **提高吞吐量**：通过减少帧间间隔和前导码开销
- **增强可靠性**：使用块确认（Block Ack）机制，减少确认帧数量
- **优化信道利用**：在单个传输机会中发送多个帧

## S-MPDU：特定场景的单帧传输

### 定义与特征
S-MPDU是指作为单个MPDU传输的帧，不进行任何聚合。尽管在大多数数据传输场景中A-MPDU更具效率，但多种场景必须使用S-MPDU。

### 必需使用S-MPDU的场景

#### 1. 组播和广播传输
组播地址MPDU不得在多MPDU的A-MPDU中传输。这是因为：
- 组播/广播帧需要被多个站点接收
- 不同站点的信道条件和能力可能差异很大
- 块确认机制不适用于组播场景

#### 2. 管理帧传输
管理帧（如信标帧、探测请求/响应、关联请求/响应等）通常以S-MPDU形式传输，原因包括：
- 需要保证可靠性和即时响应
- 管理帧通常较小，聚合收益有限
- 需要被所有站点正确接收，包括不支持A-MPDU的传统设备

#### 3. 控制帧和特定数据帧
以下帧类型需以S-MPDU或非聚合形式传输：
- 控制帧（如RTS/CTS、ACK）
- QoS Null帧
- 特定分片场景（如第16个动态分片）
- 需要立即确认的帧

#### 4. 兼容性场景
当接收端不支持A-MPDU或块确认机制时，发送端必须回退到S-MPDU传输，以确保基础通信功能。

### 伪代码决策流程

```plaintext
function determine_mpdu_type(mpdu, receiver_capabilities):
    // 检查必须使用S-MPDU的条件
    if (mpdu.destination_address.is_multicast ||
        mpdu.destination_address.is_broadcast ||
        mpdu.frame_type == MANAGEMENT ||
        mpdu.requires_immediate_ack() ||
        mpdu.is_control_frame() ||
        !receiver_capabilities.supports_ampdu ||
        current_txop_limit == 0):
        
        return S_MPDU;
    
    // 检查是否适合A-MPDU聚合
    else if (receiver_capabilities.supports_ampdu &&
             ba_agreement_exists(mpdu.tid) &&
             current_txop_limit > 0 &&
             mpdu.size + current_ampdu_size <= max_ampdu_size):
        
        return A_MPDU;
    
    // 回退到传统MPDU
    else:
        return LEGACY_MPDU;
```

## A-MPDU与S-MPDU的协同工作

### 功能互补关系
A-MPDU和S-MPDU并非相互竞争，而是功能互补的技术：
- **A-MPDU**优化高吞吐量数据传输效率
- **S-MPDU**保障控制和管理功能的可靠性

### 实际应用中的动态选择
在实际802.11ax设备中，发送端根据帧类型、接收能力、网络条件和QoS要求动态选择传输方式：

```plaintext
function transmit_frame(mpdu, receiver):
    mpdu_type = determine_mpdu_type(mpdu, receiver.capabilities);
    
    switch (mpdu_type):
        case S_MPDU:
            transmit_s_mpdu(mpdu);
            break;
        case A_MPDU:
            add_to_ampdu_aggregation(mpdu);
            if (ampdu_ready_for_transmission()):
                transmit_ampdu();
            break;
        case LEGACY_MPDU:
            transmit_legacy_mpdu(mpdu);
            break;
```

### 性能权衡考虑
网络设备需要在效率和可靠性之间进行权衡：
- 大量数据传输：优先使用A-MPDU提升吞吐量
- 关键控制和管理帧：使用S-MPDU确保及时送达
- 混合场景：根据实时网络条件动态调整

## 未来演进与展望

随着802.11be（Wi-Fi 7）等新标准的发展，帧聚合技术继续演进：
- **多链路操作**：在不同频链路上同时传输A-MPDU和S-MPDU
- **增强的聚合机制**：支持更灵活和大规模的帧聚合
- **智能调度算法**：基于机器学习动态选择最优传输方式

尽管如此，S-MPDU的基本作用不会消失，因为某些类型的帧始终需要即时和可靠的传输，而不能等待聚合。

## 总结

A-MPDU和S-MPDU在802.11ax及后续标准中各自扮演着不可或缺的角色。A-MPDU通过聚合多个MPDU子帧显著提高了吞吐量和信道效率，适用于大部分数据传输场景。而S-MPDU则在组播传输、管理帧、控制帧和兼容性场景中保持其不可替代的价值，确保了关键帧的可靠传输和系统的向后兼容。

这两种传输机制的有效结合使得现代WLAN能够在追求高效率的同时，不牺牲可靠性和兼容性。网络设备和算法需要智能地在不同场景中选择合适的传输方式，以优化整体网络性能。随着无线技术的不断发展，这种互补关系将继续演进，但基本原理将保持不变：正确的工具用于正确的场景。

## 参考资料
1. IEEE Std 802.11ax-2021 - 无线局域网介质访问控制（MAC）和物理层（PHY）规范修正案：高效WLAN增强
2. 组播地址MPDU传输限制 - 章节某某
3. 管理帧传输要求 - 章节某某
4. 块确认机制与A-MPDU关系 - 章节某某
5. 控制帧和QoS Null帧传输规范 - 章节某某
6. TXOP限制与传输格式选择 - 章节某某

## 参考资料

- 10.12.8 Transport of S-MPDUs - The rules for S MPDU operation......e The frame could be a Managem... (来源: qa_data_mac2024.new.suffix)
- 10.12 A-MPDU operation (来源: qa_data_mac2024.new.suffix)
- 26.6.3 Multi-TID A-MPDU and ack-enabled single-TID A-MPDU (来源: 11ax.suffix)
- 10.70 EDMG A-MPDU with multiple TIDs (来源: qa_data_mac2024.new.suffix)
- 10.12 A-MPDU operation - An HE STA shall not transmit a......NOTE 3 An A MSDU that meets th... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - Transmission of an A MPDU cons... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - The A MPDU shall be carried in... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - f eTransmission of an AMPDU co... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - A multi TID A MPDU shall not b... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - Transmission of a Control fram... (来源: 11ax.suffix)
- 26.4.2 Acknowledgment context in a Multi-STA BlockAck frame - A recipient of an A MPDU shall... (来源: 11ax.suffix)
- 26.4.2 Acknowledgment context in a Multi-STA BlockAck frame - If all the MPDUs in the A MPDU......For the MPDU that is a Managem... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - First any and all MPDUs that c......NOTE 2Th... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - a Initial transmission of an M... (来源: 11ax.suffix)
- 10.23.2.8 Multiple frame transmission in an EDCA TXOP (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - Transmission of one of the fol... (来源: 11ax.suffix)
- 9.7.3 A-MPDU contents - tdtdTable 9534tdtrtrtdHENonAck... (来源: 11ax.suffix)
- 9.7.3 A-MPDU contents - tdtdTable 9534ctdtrtrtdHE AckE... (来源: 11ax.suffix)
- 26.6.1 General - An A MPDU with any number of Q......NOTE 3A QoS Null frame with No... (来源: 11ax.suffix)
- 9.7.3 A-MPDU contents - tabletrtdName of contexttdtdDe... (来源: 11ax.suffix)
- Change 10.23.2.9 as follows: - Retransmission of an MPDU not ... (来源: 11ax.suffix)
- 9.7.3 A-MPDU contents - IEEE Std 80211ax 2021 IEEE Sta......than 4095 octets The 4095 octe... (来源: 11ax.suffix)
- Change 10.12.2 as follows: - Using the Maximum A MPDU Lengt... (来源: 11ax.suffix)
- 10.12.4 A-MPDU aggregation of group addressed Data frames - If the PPDU is an S1G PPDU the... (来源: qa_data_mac2024.new.suffix)
- 35.6 A-MPDU operation in an EHT PPDU - A STA affiliated with an MLD w... (来源: qa_data_11be.suffix)