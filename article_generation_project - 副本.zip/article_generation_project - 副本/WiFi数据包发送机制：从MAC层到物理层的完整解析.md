# WiFi数据包发送机制：从MAC层到物理层的完整解析

## 引言

在现代无线通信系统中，WiFi技术的演进始终围绕着一个核心目标：提高数据传输效率和可靠性。随着IEEE 802.11be（EHT）标准的推出，WiFi 7引入了多用户物理层协议数据单元（MU-PPDU）等创新技术，显著提升了多用户场景下的性能表现。本文将深入探讨WiFi数据包发送的基本原理，特别关注MAC层与物理层之间的交互机制，以及EHT标准中引入的新特性和约束条件。

理解WiFi数据包发送过程不仅对网络工程师至关重要，对从事底层网络编程的开发者也具有重要意义。通过分析数据包构建、编码选择、参数计算等关键环节，我们可以更好地优化无线网络性能，开发更高效的网络应用。

## WiFi协议栈架构概述

### MAC层与物理层的分工协作
WiFi协议栈采用分层设计架构，其中媒体访问控制（MAC）层和物理（PHY）层共同承担数据包发送的重任。MAC层负责数据帧的封装、调度和重传机制，而物理层则处理信号的调制、编码和实际传输。

在数据发送过程中，MAC层通过PHY服务接口向物理层下发传输指令和相关参数。这种交互确保了数据包能够按照既定规范进行传输，同时保持各层之间的独立性。

### EHT标准的新特性
802.11be标准引入了多项增强特性，包括更宽的信道带宽（最高320MHz）、更高阶的调制技术（4096-QAM）以及改进的多用户机制。这些改进使得WiFi 7能够支持更高的吞吐量和更低的延迟，为增强现实、虚拟现实和8K视频流等应用提供更好的支持。

## 数据包发送的核心流程

### 初始参数计算与统一化处理

在MU-PPDU传输场景中，所有用户必须使用统一的Pre-FEC填充因子（a）和符号数量（\(N_{SYM}\)）。这一要求确保了多个用户能够在同一时间段内协调传输。

初始参数计算基于各用户的 \(a_{init,u}\) 和 \(N_{SYM,init,u}\) 值，通过特定算法（式36-50）确定编码时长最长的用户索引 \(u_{\text{max}}\)。该用户的相关参数被选为公共参数基准，其他用户必须适配这些统一参数。

```pseudocode
// 伪代码：初始参数计算与统一化
FUNCTION calculate_common_parameters(users)
    FOR each user IN users
        calculate a_init[user]  // 计算初始填充因子
        calculate N_SYM_init[user]  // 计算初始符号数量
    END FOR
    
    // 确定编码时长最长的用户
    u_max = find_user_with_max_encoding_duration(users)
    
    // 设置统一参数
    common_a = a_init[u_max]
    common_N_SYM = N_SYM_init[u_max]
    
    RETURN common_a, common_N_SYM
END FUNCTION
```

### U-SIG字段结构与传输顺序

U-SIG（Universal Signal）字段是EHT标准中引入的新组件，由U-SIG-1和U-SIG-2两部分组成，各包含26个数据比特。这一设计确保了向后兼容性和前向兼容性。

传输过程中，U-SIG-1优先传输，包含了接收端解析数据包所需的关键信息。U-SIG-2则携带额外的控制信息，共同为数据段的正确解码提供必要参数。

## 编码机制与参数调整

### LDPC编码的动态调整

低密度奇偶校验（LDPC）编码是WiFi系统中用于错误校正的重要技术。在EHT标准中，LDPC编码需要动态调整符号数量以适应不同的传输条件。

当初始填充因子 \(a_{init} = 4\) 时，系统执行以下调整：
- \(N_{SYM} = N_{SYM,init} + m_{STBC}\)
- \(a = 1\)

其他情况下：
- \(N_{SYM} = N_{SYM,init}\)
- \(a = a_{init} + 1\)

```pseudocode
// 伪代码：LDPC编码参数调整
FUNCTION adjust_ldpc_parameters(a_init, N_SYM_init, m_STBC)
    IF a_init == 4 THEN
        N_SYM = N_SYM_init + m_STBC
        a = 1
    ELSE
        N_SYM = N_SYM_init
        a = a_init + 1
    END IF
    
    RETURN a, N_SYM
END FUNCTION
```

### LDPC适用性约束校验

系统必须校验LDPC编码的适用性约束条件，这些条件涉及 \(N_{punc,u}\)（穿孔比特数）和 \(N_{shrt,u}\)（缩短比特数）之间的阈值关系。如果约束条件不满足，系统将回退至BCC（二进制卷积码）编码方案。

这种灵活性确保了在不同信道条件下都能选择最合适的编码方案，优化传输性能。

### BCC编码的预处理

对于使用BCC编码的用户，Pre-FEC填充比特数的计算需要结合TXVECTOR中的多个参数，包括APEP_LENGTH、\(N_{tail,u}\) 和 \(N_{service}\)。这些参数共同决定了填充比特的数量和分布。

末尾符号的数据比特数 \(N_{DBPS,last,u}\) 和编码比特数 \(N_{CBPS,last,u}\) 根据a值计算（参考式36-61和36-62），这些计算确保了数据的完整性和正确性。

## 调制与编码策略（MCS）的特殊考量

### EHT-MCS 14的特殊处理

EHT-MCS 14在不同带宽配置下具有不同的 \(N_{SD,short}\) 值：
- 80MHz带宽：60
- 160MHz带宽：120
- 320MHz带宽：246

这种变化反映了不同带宽条件下子载波分配的灵活性，确保了频谱资源的高效利用。

### 其他MCS的参考值

对于其他MCS级别，\(N_{SD,short}\) 值参考表36-46。例如，26-tone RU在MCS 0-13时的 \(N_{SD,short}\) 值为6，而在MCS 15时降为2。这些值的变化考虑了不同调制编码方案下的可靠性和效率平衡。

## 完整编程实现框架

### 系统初始化与参数设置

```pseudocode
// 伪代码：WiFi数据包发送完整流程
FUNCTION send_wifi_packet(users, tx_parameters)
    // 初始化各用户参数
    FOR each user IN users
        initialize_user_parameters(user, tx_parameters)
    END FOR
    
    // 确定公共a和N_SYM
    common_a, common_N_SYM = calculate_common_parameters(users)
    
    // 计算各用户末尾符号的比特/载波数
    FOR each user IN users
        N_DBPS_last[user] = calculate_N_DBPS_last(user, common_a)
        N_CBPS_last[user] = calculate_N_CBPS_last(user, common_a)
    END FOR
    
    // 校验LDPC约束条件
    IF check_ldpc_constraints(users) == TRUE THEN
        encoding_scheme = LDPC
    ELSE
        encoding_scheme = BCC
    END IF
    
    // 处理U-SIG字段结构
    usig_field = construct_usig_field(users, tx_parameters)
    
    // 处理TXVECTOR参数
    process_txvector_parameters(tx_parameters)
    
    // 处理信号扩展PPDU
    IF requires_signal_extension(tx_parameters) THEN
        append_extension_symbols()
    END IF
    
    // 执行实际传输
    perform_transmission(users, encoding_scheme)
END FUNCTION
```

### 约束条件校验实现

```pseudocode
// 伪代码：LDPC约束条件校验
FUNCTION check_ldpc_constraints(users)
    FOR each user IN users
        // 计算N_punc和N_shrt
        N_punc[user] = calculate_punctured_bits(user)
        N_shrt[user] = calculate_shortened_bits(user)
        
        // 检查阈值关系
        IF NOT validate_threshold_relation(N_punc[user], N_shrt[user]) THEN
            RETURN FALSE
        END IF
    END FOR
    
    RETURN TRUE
END FUNCTION
```

### TXVECTOR参数处理

TXVECTOR包含了控制传输过程的各种参数，在EHT_MU格式下，需要特别注意TXPWR_LEVEL_INDEX的范围限制。这些参数确保了传输功率的精确控制和合规性。

```pseudocode
// 伪代码：TXVECTOR参数处理
FUNCTION process_txvector_parameters(tx_parameters)
    // 验证参数有效性
    IF NOT validate_txvector(tx_parameters) THEN
        throw_error("Invalid TXVECTOR parameters")
    END IF
    
    // 特别处理EHT_MU格式下的功率控制参数
    IF tx_parameters.format == EHT_MU THEN
        validate_txpwr_level_index(tx_parameters.txpwr_level_index)
    END IF
    
    // 处理其他相关参数
    process_apep_length(tx_parameters.apep_length)
    process_service_parameters(tx_parameters.N_service)
END FUNCTION
```

## 性能优化与实践考量

### 资源分配策略

在实际部署中，资源分配策略对系统性能有重要影响。通过智能分配RU（资源单元）和优化MCS选择，可以显著提高频谱效率和用户公平性。

### 延迟与吞吐量平衡

WiFi系统需要在延迟和吞吐量之间找到最佳平衡。通过调整帧聚合大小、选择适当的确认策略和优化重传机制，可以在不同应用场景下实现性能最优化。

### 实际部署注意事项

在实际网络环境中，开发者需要考虑多路径衰落、干扰管理和功耗控制等因素。这些实际约束条件往往需要在标准协议基础上进行适当的调整和优化。

## 总结

WiFi数据包发送是一个复杂而精密的过程，涉及MAC层与物理层的紧密协作、多种编码方案的动态选择以及大量参数的精确计算。随着EHT标准的推出，这一过程变得更加复杂但也更加高效。

通过本文的探讨，我们深入了解了WiFi数据包发送的基本原理和实现细节，包括参数计算、编码选择、约束校验等关键环节。这些知识不仅有助于理解无线通信的工作原理，也为从事网络编程和协议开发的工程师提供了实用的技术参考。

未来，随着无线技术的持续演进，我们可以期待更多创新技术的出现，进一步提升WiFi网络的性能和可靠性。对于技术从业者而言，持续跟踪协议发展并深入理解底层机制，将是保持技术竞争力的关键。


## 参考资料

- 27.3.21 HE transmit procedure - Typical PHY receive procedures......httpscdnmineruopenxlaborgcnres... (来源: 11ax.suffix)
- 10.44.3.2.3 Data transmission rules - As shown in the example of Fig......Figure 10139Example of data tr... (来源: qa_data_mac2024.new.suffix)
- 10.3.1 General - A Data frame sent under the DC......While in the awake state and o... (来源: qa_data_mac2024.new.suffix)
- 36.3.6 Transmitter block diagram - The generation of each field i......u Windowing (来源: qa_data_11be.suffix)
- 36.3.11.4 Transmitted signal - gammak320  left beginarrayll1 ......where  Phi1Phi2Phi3  are imple... (来源: qa_data_11be.suffix)
- 36.3.7.10 Construction of Data field in an EHT PPDU - Construct the Data field as de......For each user (来源: qa_data_11be.suffix)
- 36.3.23 EHT receive procedure - Typical PHY receive procedures......A typical state machine implem... (来源: qa_data_11be.suffix)
- 27.3.15 Transmit requirements for PPDUs sent in response to a triggering frame (来源: 11ax.suffix)
- 27.3.5 Transmitter block diagram - httpscdnmineruopenxlaborgcnres... (来源: 11ax.suffix)
- 27.3.5 Transmitter block diagram - a preFEC PHY padding  b Scramb... (来源: 11ax.suffix)
- 17.3.5.5 PHY DATA scrambler and descrambler - NONHT equals CBW20 or CBW320 a... (来源: qa_data_11be.suffix)
- 10.3 DCF (来源: qa_data_mac2024.new.suffix)
- 10.2.2 DCF - For a STA to transmit it shall... (来源: qa_data_mac2024.new.suffix)
- 10.3.4.3 Backoff procedure for DCF - The effect of this procedure i... (来源: qa_data_mac2024.new.suffix)
- 10.3.4.3 Backoff procedure for DCF - If the medium is determined to......Transmission shall commence wh... (来源: qa_data_mac2024.new.suffix)
- 10.3.4.3 Backoff procedure for DCF - A backoff procedure shall be p... (来源: qa_data_mac2024.new.suffix)
- 10.3.7 DCF timing relations - The PIFS and DIFS are derived ......In a non S1G STA when dot11Dyn... (来源: qa_data_mac2024.new.suffix)
- 27.3.11.8.5 Encoding and modulation - Further padding bits are appen... (来源: 11ax.suffix)
- 27.2.1 Introduction - The PHY provides an interface ......The MAC uses the TXVECTOR to s... (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - beginarrayrl  NPADmathrmPre  F......NSYMinit  mSTBCcdot leftlceil ... (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - Among the pre FEC padding bits... (来源: 11ax.suffix)
- 36.3.22 EHT transmit procedure - The PHY indicates the state of......After the PHY preamble transmi... (来源: qa_data_11be.suffix)
- 36.2.1 Introduction - The PHY provides an interface ......The MAC uses the TXVECTOR to s... (来源: qa_data_11be.suffix)
- 27.3.11.8.5 Encoding and modulation - httpscdnmineruopenxlaborgcnres......IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 27.3.5 Transmitter block diagram - The BCC encoder and interleave......IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 10.15 Low-density parity check code (LDPC) operation - dot11S1GLDPCCodingOptionActiva......Further restrictions on TXVECT... (来源: qa_data_mac2024.new.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - Among the pre FEC padding bits......NP A DmathrmPre  FECM A Cu  8c... (来源: qa_data_11be.suffix)
- 27.3.6.10.2 Using LDPC - The construction of the Data f......IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 27.3.6.10.2 Using LDPC - b PreFEC padding Append the pr... (来源: 11ax.suffix)
- 36.3.13.3.3 LDPC coding - LDPC is the only FEC coding sc......Otherwise support of LDPC codi... (来源: qa_data_11be.suffix)
- 27.3.12.5 Coding - Support for LDPC coding for bo... (来源: 11ax.suffix)
- 27.3.12.5 Coding - LDPCC is the only FEC coding s... (来源: 11ax.suffix)
- 27.3.12.5.2 LDPC coding - Navbits  left beginarrayllNavb......If in step d of the LDPC encod... (来源: 11ax.suffix)
- 10.15 Low-density parity check code (LDPC) operation - An HT STA shall not transmit a... (来源: qa_data_mac2024.new.suffix)
- 10.15 Low-density parity check code (LDPC) operation - An HE STA shall not transmit a... (来源: qa_data_mac2024.new.suffix)
- 27.3.11.7.2 Content - Set to 1 if an LDPC extra symb... (来源: 11ax.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - If none of the users with LDPC......For the users with BCC encodin... (来源: qa_data_11be.suffix)
- 27.3.6.10.2 Using LDPC - n Spatial mapping Apply the  Q... (来源: 11ax.suffix)
- 36.3.13.3.2 BCC coding - Support for BCC coding is limi......If EHT MCS 15 BPSK DCM with  N... (来源: qa_data_11be.suffix)
- 27.3.12.5 Coding - The Data field shall be encode......When conducting BCC FEC encodi... (来源: 11ax.suffix)
- 27.3.6.11.3 Using LDPC - In an HE MU transmission the P......A Data field with LDPC encodin... (来源: 11ax.suffix)
- 27.3.12.5.2 LDPC coding - In addition in step d of the L......then the LDPC Extra Symbol Seg... (来源: 11ax.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - For each user with LDPC encodi......where  Npuncu   NCWu   LLDPCu ... (来源: 11ax.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - Then the LDPC Extra Symbol Seg......Update the common pre FEC padd... (来源: 11ax.suffix)
- 27.1.1 Introduction to the HE PHY - An HE SU PPDU with a bandwidth......LDPC coding transmit and recei... (来源: 11ax.suffix)
- 27.3.12.5.2 LDPC coding - For an HE SU PPDU or HE ER SU ......Navbits  NSYMinit  mSTBCcdot N... (来源: 11ax.suffix)
- 10. MAC sublayer functional description (来源: qa_data_mac2024.new.suffix)
- 10.2 MAC architecture (来源: qa_data_mac2024.new.suffix)
- 27.3.12.5.5 Encoding process for an HE TB PPDU - For an HE TB PPDU sent in resp... (来源: 11ax.suffix)
- 36.3.13.3.6 Encoding process for an EHT TB PPDU - For an EHT TB PPDU with LDPC e......left beginarrayllainit  4mathr... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - 11 Introduction to the EHT PHY... (来源: qa_data_11be.suffix)
- 36.1.4 PPDU formats - The structure of the PPDU tran......The FORMAT parameter determine... (来源: qa_data_11be.suffix)
- 26.5.2.3.3 TXVECTOR parameters for HE TB PPDU response to Trigger frame - IEEE Std 80211ax 2021IEEE Stan... (来源: 11ax.suffix)
- 10.3.2.13.1 Acknowledgment procedure for DL MU PPDU in SU PPDU - Change the text in 1032131 as ......NOTE 1All MPDUs transmitted wi... (来源: 11ax.suffix)
- 26.12 HE PPDU post-FEC padding and packet extension - IEEE Std 80211ax 2021 IEEE Sta......Table 2613PPE thresholds per P... (来源: 11ax.suffix)
- 26.5.2.2.1 General - An AP that transmits a PPDU ma......Including in the PPDU one or m... (来源: 11ax.suffix)
- 27.3.21 HE transmit procedure - A packet extension andor a sig......Once the PPDU transmission is ... (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - The pre FEC padding process is......where (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - A two step padding process is ......Four pre FEC padding boundarie... (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - beginarrayrl  NPADmathrmPre  F... (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - Figure 27 36 illustrates these......Figure 2736HE PPDU padding pro... (来源: 11ax.suffix)
- 26.12 HE PPDU post-FEC padding and packet extension - After receiving the PPE Thresh......NOTE If the pre FEC padding fa... (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - mSTBC  is 2 if STBC is used an......where (来源: 11ax.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - Among the pre FEC padding bits......beginarrayrl  NPADmathrmPre  F... (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - NDBPSshort  NCBPSshortcdot R  ......tabletrtd rowspan2RU sizetdtd ... (来源: 11ax.suffix)
- 27.3.12.5.2 LDPC coding - beginarraycNSYM  NSYMinit a  a......Authorized licensed use limite... (来源: 11ax.suffix)
- 26.12 HE PPDU post-FEC padding and packet extension - For all values of  n  and  b  ... (来源: 11ax.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - For each user with LDPC encodi... (来源: qa_data_11be.suffix)
- 36.3.13.3.4 EHT PPDU padding process - A two step padding process is ......Four pre FEC padding boundarie... (来源: qa_data_11be.suffix)
- 27.3.11.7.2 Content - Set to 1 to indicate a preFEC ... (来源: 11ax.suffix)
- 27.3.12.5.3 Post-FEC padding - The number of post FEC padding......The last  mSTBC  symbols shall... (来源: 11ax.suffix)
- 27.4.3 TXTIME and PSDU_LENGTH calculation - IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 26.12 HE PPDU post-FEC padding and packet extension - tdtd rowspan2Nominal packet pa... (来源: 11ax.suffix)
- 27.3.6.2 Construction of L-STF field - IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 27.3.12.2 Pre-FEC padding process - Authorized licensed use limite......For an HE SU PpDU and HE ER SU... (来源: 11ax.suffix)
- 27.3.12.4 Scrambler - The SERVICE field of HE PpDU i......The SERVICE field PSDU and pre... (来源: 11ax.suffix)
- 27.4.3 TXTIME and PSDU_LENGTH calculation - IEEE Std 80211ax 2021 IEEE Sta......TPE  is given in 27313 (来源: 11ax.suffix)
- 26.15.3 MCS, NSS, BW, and DCM selection - IEEE Std 80211ax 2021 IEEE Sta......DCM encoding if the most recen... (来源: 11ax.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - left beginarrayllNSYM  NSYMini......If none of the users with LDPC... (来源: 11ax.suffix)
- 36.2.6.1 General - The MAC interacts with the PHY... (来源: qa_data_11be.suffix)
- 27.3.5 Transmitter block diagram - httpscdnmineruopenxlaborgcnres......IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - beginarrayrNDBPSlastinitu  lef......beginarrayrNPADmathrmPre  FECu... (来源: 11ax.suffix)
- 27.4.3 TXTIME and PSDU_LENGTH calculation - For an HE MU PPDU the value of......if  a  1   the Coding field is... (来源: 11ax.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - For an HE MU PPDU all the user......where (来源: 11ax.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - Authorized licensed use limite......beginarrayrl  Npldu  NSYMinit ... (来源: 11ax.suffix)
- 27.3.12.5.5 Encoding process for an HE TB PPDU - If the TXVECTOR parameter TRIG... (来源: 11ax.suffix)
- 36.3.11.4 Transmitted signal - beginarrayrl  rPPDUiTXt    rma......where (来源: qa_data_11be.suffix)
- 36.2 EHT PHY service interface (来源: qa_data_11be.suffix)
- 27.3.11.7.4 Encoding and modulation - For an HE SU PPDU HE MU PPDU a... (来源: 11ax.suffix)
- 36.3.7.6 Construction of U-SIG - b BCC encoder Encode the data ... (来源: qa_data_11be.suffix)
- 36.3.7.5 Construction of RL-SIG - b BCC encoder Encode the RLSIG... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - beginarrayrl  Npuncu  01times ......where  Npuncu NCWu LLDPCu  and... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - For the users with BCC encodin......NP A DmathrmPost  FECu  NC B P... (来源: qa_data_11be.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - arg max fxcoloneqq xxin 0Nuser......Calculate each users initial n... (来源: 11ax.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - For the users with BCC encodin......NPADmathrmPost  FECu  NCBPSu  ... (来源: 11ax.suffix)
- 27.1.1 Introduction to the HE PHY - LDPC coding transmit and recei......HE SU PPDUs and HE ER SU PPDUs... (来源: 11ax.suffix)
- 27.3.12.5.5 Encoding process for an HE TB PPDU - If the TXVECTOR parameter TRIG......For an HE TB PPDU with LDPC en... (来源: 11ax.suffix)
- 27.3.12.10 LDPC tone mapper - tabletrtd rowspan2Parametertdt......For an HE PDDU without DCM the... (来源: 11ax.suffix)
- 27.3.12.1 General - symbols in an HE PPDU shall us......If BCC encoding is used the Da... (来源: 11ax.suffix)
- 27.3.12.10 LDPC tone mapper - tk  left beginarrayllDTMBigkbm......For an HE PDDU with DCM applie... (来源: 11ax.suffix)
- 27.3.12.5.5 Encoding process for an HE TB PPDU - For an HE TB PPDU sent in resp......For an HE TB PPDU with BCC enc... (来源: 11ax.suffix)
- 27.3.6.6 Construction of HE-SIG-A field - a For an HE SU PPDU HE MU PPDU......2 BCC encoder Encode the data ... (来源: 11ax.suffix)
- 27.3.12.5.5 Encoding process for an HE TB PPDU - If the TXVECTOR parameter TRIG......where  mSTBC  is 2 if the Trig... (来源: 11ax.suffix)
- 36.3.13.3.6 Encoding process for an EHT TB PPDU - For an EHT TB PPDU sent in res......For an EHT TB PPDU with BCC en... (来源: qa_data_11be.suffix)
- 36.4.3 TXTIME and PSDU_LENGTH calculation - aR Xu  left beginarrayl lmathr......a  is the pre FEC padding fact... (来源: qa_data_11be.suffix)
- 27.4.3 TXTIME and PSDU_LENGTH calculation - mathrmPSDULENGTHu  leftlfloor ......NSYMRX  is given by Equation 2... (来源: 11ax.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - NP A DmathrmPre  FECP H Yu  NP... (来源: qa_data_11be.suffix)
- 27.4.3 TXTIME and PSDU_LENGTH calculation - NSYMinit  is given by Equation......mathrmPSDULENGTHu  leftlfloor ... (来源: 11ax.suffix)
- 27.4.3 TXTIME and PSDU_LENGTH calculation - NSYMRX  left beginarraycmathrm......where  aRX  is given by Equati... (来源: 11ax.suffix)
- 36.4.3 TXTIME and PSDU_LENGTH calculation - NSYMinit  is given by Equation......where (来源: qa_data_11be.suffix)
- 36.4.3 TXTIME and PSDU_LENGTH calculation - TPE  is given in 36314 Packet ......NSYMinit  is given in 3631336 ... (来源: qa_data_11be.suffix)
- 27.3.6.10.2 Using LDPC - h Constellation mapper Map to ... (来源: 11ax.suffix)
- 27.4.3 TXTIME and PSDU_LENGTH calculation - if  a  1   Coding field is 1 i......The value of the PSDULENGTH pa... (来源: 11ax.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - Nanu b i t su  left beginarray......left beginarrayllNSYM  NSYMini... (来源: qa_data_11be.suffix)
- 36.1.1 Introduction to the EHT PHY - LDPC coding transmit and recei......Single spatial stream EHT MCSs... (来源: qa_data_11be.suffix)
- 27.3.12.10 LDPC tone mapper - tk  left beginarrayl lDT M D C......is the LDPC tone mapping dista... (来源: 11ax.suffix)
- 36.3.13.8 LDPC tone mapper - k  01ldots 2NSD l  1  for the ......beginarraylu  01ldots Nuserr  ... (来源: qa_data_11be.suffix)
- 36.3.13.8 LDPC tone mapper - NSD l  is the number of data t......tkl  left beginarrayllDmathrmT... (来源: qa_data_11be.suffix)
- 10.15 Low-density parity check code (LDPC) operation - A VHT STA shall not transmit a......An S1G STA shall not transmit ... (来源: qa_data_mac2024.new.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - ainitu  left beginarrayll4  ma......NDBPSshortu  NCBPSshortucdot R... (来源: qa_data_11be.suffix)
- 36.3.13.8 LDPC tone mapper - n  01ldots NSYM  1  for a 26 5......tkl  DmathrmTMlBigkmathrmmodfr... (来源: qa_data_11be.suffix)
- 27.3.12.5.4 Encoding process for an HE MU PPDU - a  ainitNSYM  NSYMinit tag2784...NC B P Sl a s tu  left beginar... (来源: 11ax.suffix)
- 36.3.13.8 LDPC tone mapper - k  01ldots NSD l  1  for a 26 ... (来源: qa_data_11be.suffix)
- 36.3.13.8 LDPC tone mapper - For an EHT PPDU without DCM th......i  12dotsNSSru (来源: qa_data_11be.suffix)
- 36.2.5 Effect of CH_BANDWIDTH parameter on PPDU format - tdtrtable (来源: qa_data_11be.suffix)
- 35.3.16.5 PPDU end time alignment on a NSTR link pair (来源: qa_data_11be.suffix)
- 36.3.7.10 Construction of Data field in an EHT PPDU - h BCC interleaver If the user ......j LDPC tone mapper If the user... (来源: qa_data_11be.suffix)
- 36.3.13.3.6 Encoding process for an EHT TB PPDU - Then continue with the LDPC en......If the TXVECTOR parameter TRIG... (来源: qa_data_11be.suffix)
- 36.3.16 Transmit requirements for PPDUs sent in response to a triggering frame (来源: qa_data_11be.suffix)
- 36.3.20.1.1 General - For an  80mathrmMHz  mask PPDU......Figure 3661Example transmit sp... (来源: qa_data_11be.suffix)
- 36.3.13.3.6 Encoding process for an EHT TB PPDU - If the TXVECTOR parameter TRIG... (来源: qa_data_11be.suffix)
- 27.3.6.10 Construction of the Data field in an HE SU PPDU, HE ER SU PPDU, and HE TB PPDU (来源: 11ax.suffix)
- 27.3.12.1 General - The Data field of the HE PPDU ... (来源: 11ax.suffix)
- 26.12 HE PPDU post-FEC padding and packet extension - A STA transmitting an HE PPDU ... (来源: 11ax.suffix)
- 26.6.2.2 A-MPDU padding in an HE SU PPDU, HE ER SU PPDU, and HE MU PPDU - An HE STA that transmits a DL ......An HE STA that transmits an HE... (来源: 11ax.suffix)
- 26.15.2 PPDU format selection - An HE STA shall not transmit a... (来源: 11ax.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - NDBPSlastu  left beginarraylla......NP A DmathrmPre  FECu  NS Y Mi... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - The encoding process described......where (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - APEP LENGTH  u  is the TXVECTO......Based on  NExcessu   the trans... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - beginarrayrl  NSYMinit  NSYMin......NC B P Sl a s ti n i tu  left ... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - MRU 2996484 and MRU 3996484 Se... (来源: qa_data_11be.suffix)
- 27.1.1 Introduction to the HE PHY - Transmission of an HE MU PPDU ... (来源: 11ax.suffix)
- 36.3.4 EHT PPDU formats - A PPDU containing a signal ext... (来源: qa_data_11be.suffix)
- 36.1.4 PPDU formats - Non HT format NONHT based on C... (来源: qa_data_11be.suffix)
- 36.3.12.11.1 General - Transmission of an EHT PPDU wi... (来源: qa_data_11be.suffix)
- 36.1.4 PPDU formats - HE MU PPDU format HE MU as def... (来源: qa_data_11be.suffix)
- 35.14.2 PPDU format selection - An EHT STA may transmit a Bloc... (来源: qa_data_11be.suffix)
- 36.3.12.7.2 Content - If the PPDU Type And Compressi......Table 3630Definition of the Pu... (来源: qa_data_11be.suffix)
- 36.2.2 TXVECTOR and RXVECTOR parameters - 0 indicates that an LDPC extra... (来源: qa_data_11be.suffix)
- 36.4.3 TXTIME and PSDU_LENGTH calculation - NDBPSlastRXu  left beginarrayl......NSSu   NBPRSu   Ru  are define... (来源: qa_data_11be.suffix)
- 27.3.10 Mathematical description of signals - For an HE TB PPDU the total po......NNormr  If the TXVECTOR parame... (来源: 11ax.suffix)
- 36.3.12.7.3 Encoding and modulation - For an EHT MU PPDU and EHT TB ... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - Table 3647NSDshort values for ......Then the common  ainit  and  N... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - The parameter  NSDshort  value......tabletrtd rowspan2RU or MRU si... (来源: qa_data_11be.suffix)
- 36.3.13.3.5 Encoding process for an EHT MU PPDU - Authorized licensed use limite......Table 3646NSDshort values for ... (来源: qa_data_11be.suffix)
