# 无线网络中的Duration字段：精准设置与时间同步的关键

## 引言

在现代无线通信系统中，时间同步和介质访问控制是确保高效数据传输的基础。IEEE 802.11标准中的Duration字段作为关键的时序控制机制，在帧传输过程中发挥着至关重要的作用。这个字段不仅决定了信道预留时间的长短，还直接影响着网络吞吐量、碰撞避免机制以及整体系统性能。本文将深入探讨Duration字段的设置规则，分析不同帧类型下的计算方式，并揭示其在维持无线网络时序完整性中的核心作用。

## Duration字段的基本概念与作用

### 字段定义与功能
Duration字段是MAC帧头部的重要组成部分，采用16位编码，用于指示当前传输序列需要预留的介质访问时间（以微秒为单位）。其主要功能包括：

1. **网络分配向量（NAV）设置**：通过Duration字段值，接收站点可以设置NAV定时器，实现虚拟载波侦听
2. **传输序列保护**：确保多帧交换序列（如RTS/CTS、Poll/SPR/Grant）的完整性
3. **时间同步**：在定向多吉比特（DMG）传输中维持精确的时间同步

### 通用计算原则
无论何种帧类型，Duration字段的计算都遵循几个基本原则：
- 所有时间计算均以微秒为单位
- 计算结果若包含小数微秒，必须向上取整到下一个整数微秒值
- 计算需考虑帧传输时间、各种帧间间隔（IFS）以及可能的保护时间

## 不同帧类型的Duration字段设置规则

### DMG Beacon帧中的Duration设置

在60GHz频段的DMG网络中，Beacon帧的Duration字段设置具有特殊规则。通常情况下，该字段设置为当前信标传输间隔（BTI）结束前的剩余时间。但在增强型DMG（EDMG）BSS中，当Next A-BFT子字段为0且A-BFT Multiplier大于0时，需要采用特殊计算方式：

```
Duration = BTI剩余时间 + MBIFS时间 + (A-BFT Length × A-BFT Multiplier)
```

这种计算确保了波束成形训练阶段（A-BFT）能够获得足够的时间资源，同时避免了与其他传输序列的时间冲突。

### RTS/CTS交换机制中的Duration计算

RTS/CTS握手机制是避免隐藏节点问题的关键技术，其Duration字段设置需要精确覆盖整个传输序列：

**RTS帧**：Duration值必须覆盖完整的四次握手过程：
- CTS帧传输时间
- SIFS间隔
- 数据帧传输时间
- ACK帧传输时间及相关间隔

计算公式为：
```
Duration_RTS = T_CTS + aSIFSTime + T_Data + aSIFSTime + T_ACK
```

**CTS帧**：从接收到的RTS帧Duration值中扣除已消耗的时间：
```
Duration_CTS = Duration_RTS - aSIFSTime - T_CTS
```

对于NDP（Null Data Packet）CTS帧，还需要额外减去NDP传输时间（NDPTxTime），具体计算遵循IEEE 802.11标准10.3.2.5.2节的规定。

### Poll/SPR/Grant帧序列的Duration协调

在服务周期分配机制中，Poll、SPR和Grant帧形成了一个精密的时间协调系统：

**Poll帧**采用复合计算公式：
```
Di = Di,n + Om + Ceil(TXTIME(SPRm), TTR)
```
其中Di,n表示剩余Poll传输的持续时间，Om表示SPR传输偏移量，Ceil函数确保时间值向上取整到TSF分辨率（TTR）的倍数。

**SPR帧**的Duration计算基于接收到的Poll帧：
```
Duration_SPR = Duration_Poll - Response_Offset - T_SPR
```

**Grant帧**则需要考虑服务周期的剩余时间：
```
Duration_Grant = SP_Remaining_Time - T_Grant - aSIFSTime
```

这种分层计算体系确保了整个服务周期分配过程的时间精确性和资源利用效率。

### DMG DTS帧的特殊计算规则

定向传输同步（DTS）帧在DMG网络中具有独特的Duration计算方式。根据接收站点的监听状态，有两种计算方式：

1. **基于NAV的计算**：从目标站点当前最大NAV值中减去DTS帧传输时间
2. **基于监听时间的计算**：当接收站点监听时间不足aDMGPPMinListeningTime时：
```
Duration_DTS = aDMGPPMinListeningTime - 已监听时间
```

这种灵活性确保了在不同网络状态下都能维持精确的时间同步。

## 特殊场景下的Duration字段设置

### ATI期间的Duration设置

在宣布传输间隔（ATI）期间，Duration字段的设置遵循特殊规则：

- **请求帧**：Duration覆盖ATI剩余时间，确保响应帧有足够的传输时间
- **响应帧**：Duration = 请求帧Duration - SIFS - 响应帧传输时间

这种设置保证了ATI期间的控制帧交换不会超出分配的时间范围。

### 分片传输中的Duration调整

在数据分片传输场景中，Duration字段的设置需要适应分片特性：

- **非最后分片**：Duration设置为足够覆盖下一个分片传输及确认的时间
- **最后分片**：Duration设置为ACK传输时间加上SIFS时间
- **对应的ACK帧**：Duration设置为0，表示传输序列结束

这种渐进式的Duration调整确保了分片传输过程的时间效率。

### 保护机制下的Duration一致性

当使用RTS/DMG CTS帧作为保护机制时，Duration字段的计算规则保持不变。这种一致性确保了保护机制不会引入额外的时间计算复杂度，同时维持了与传统传输机制的兼容性。

## Duration字段设置的最佳实践与注意事项

### 时间计算精度管理

由于无线环境的时间敏感性，Duration计算需要特别注意：

1. **向上取整原则**：所有含小数的微秒值必须向上取整，避免时间预留不足
2. **时钟同步**：考虑本地时钟与网络时钟的同步差异
3. **传输时间估算**：准确计算TXTIME，考虑实际调制编码方案（MCS）

### 错误处理与恢复机制

在实际部署中，需要考虑Duration设置错误的处理策略：

1. **NAV恢复机制**：当Duration设置异常时，站点应具备NAV重置能力
2. **超时检测**：实现定时器监控Duration设置的正确性
3. **动态调整**：根据网络状况动态调整Duration计算参数

### 性能优化考虑

优化的Duration设置可以显著提升网络性能：

1. **最小化预留时间**：在保证传输完整性的前提下最小化Duration值
2. **适应信道条件**：根据信道质量动态调整Duration计算
3. **功耗优化**：通过精确的Duration设置降低站点功耗

## 总结

Duration字段的正确设置是无线网络高效运行的关键技术细节。通过本文的分析可以看出，不同帧类型和传输场景下的Duration计算规则既体现了工程设计的一致性，又展示了适应特定需求的灵活性。从DMG Beacon帧的复杂时间计算到RTS/CTS交换的精确时序控制，从Poll/SPR/Grant序列的协调到特殊场景的适配，Duration字段的设置艺术体现了无线通信系统中时间同步的精髓。

在实际系统设计和实现中，工程师需要深入理解各种场景下的Duration计算规则，同时考虑实际部署环境的具体特点。随着新一代无线标准的发展，Duration字段的设置机制将继续演进，但其核心目标——确保传输序列的完整性和时间同步的精确性——将始终保持不变。掌握这些设置规则不仅有助于优化网络性能，还能为解决复杂的无线通信问题提供重要基础。