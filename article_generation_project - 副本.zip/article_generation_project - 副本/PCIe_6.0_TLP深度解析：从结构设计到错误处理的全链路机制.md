# PCIe 6.0 TLP深度解析：从结构设计到错误处理的全链路机制

> 在现代数据中心和高性能计算环境中，PCIe 6.0作为第三代I/O技术标准，其传输速率达到64 GT/s，但高速传输背后的数据可靠性和完整性保障机制才是真正的技术核心。Transaction Layer Packet（TLP）作为PCIe协议栈的事务层核心单元，承载着所有数据交换的关键任务。

PCIe 6.0在TLP设计上引入了多项创新机制，包括增强的前缀规则、完整性及数据加密（IDE）支持、更严格的错误处理流程等。这些机制共同确保了在翻倍带宽的同时，数据传递的可靠性和安全性得到同步提升。

本文将深入解析PCIe 6.0规范中TLP的类型结构、前缀处理规则、IDE机制和错误处理体系，为硬件工程师和系统架构师提供全面的技术参考。

## 1. TLP基础结构与类型体系

### 1.1 TLP组成要素

PCIe 6.0中的TLP包含四个主要部分：可选前缀、头部、数据载荷及摘要字段。这种分层结构设计允许在保持向后兼容性的同时引入新功能。

前缀字段分为本地前缀和端到端前缀两类，为TLP提供了额外的控制信息和元数据承载能力。头部字段则包含了路由信息、事务类型、长度等关键参数，决定了TLP的基本行为和传输路径。

### 1.2 事务类型分类

TLP按功能分为请求类和完成类两大类型，支持四种基本事务：

- **内存事务**：MRd（内存读）、MRdLk（锁定内存读）、MWr（内存写）
- **I/O事务**：IORd（I/O读）、IOWr（I/O写）
- **配置事务**：CfgRd0/1（配置读）、CfgWr0/1（配置写）
- **消息事务**：多种消息类型，用于事件通知、错误报告等

## 2. TLP前缀处理机制

### 2.1 端到端前缀支持规则

PCIe 6.0规范对端到端TLP前缀的支持提出了明确要求。根端口必须设置End-End TLP Prefix Supported位以表明其前缀处理能力，但规范并不要求根复合体（RC）在所有根端口对之间都支持前缀路由功能。

```mermaid
graph TD
    A[TLP with End-End Prefix] --> B{Routing between<br>Root Ports};
    B -->|Supported| C[Normal Processing];
    B -->|Unsupported| D{Request or Completion?};
    D -->|Request| E[Handle as UR];
    D -->|Completion| F[Handle as UC];
    E --> G[Error Reported by Sending Port];
    F --> G;
```

当TLP需要在**不支持前缀路由的端口对**之间传输时，系统必须按规范要求进行错误处理：请求类事务按不支持请求（UR）处理，完成类事务按意外完成（UC）处理，相关错误由发送端口负责上报。

### 2.2 厂商自定义前缀

PCIe 6.0允许厂商定义自定义前缀，但这些前缀必须显式启用才能使用。这种设计平衡了扩展灵活性和 interoperability 要求，确保不同厂商设备间的正常互操作。

## 3. 完整性及数据加密（IDE）机制

### 3.1 选择性IDE流支持

PCIe 6.0引入了选择性IDE流机制，但并非所有TLP类型都支持此功能。根据规范表6-33的定义：

| TLP类型 | 描述 | 允许使用选择性IDE流 |
|---------|------|-------------------|
| MRd | 内存读请求 | 是 |
| MRdLk | 内存读请求-锁定 | 是 |
| MWr | 内存写请求 | 是 |
| IORd | I/O读请求 | 否 |
| IOWr | I/O写请求 | 否 |
| CfgRd0/1 | 配置读 | 否 |
| CfgWr0/1 | 配置写 | 否 |
| Cpl/CplD/CplDLk | 完成事务 | 是 |

当接收到非允许类型的IDE TLP时，会触发IDE检查失败错误，接收方必须将相关流转为非安全状态。这种限制是基于不同类型事务的安全要求和性能权衡做出的设计决策。

### 3.2 IDE Fail消息传输规则

IDE Fail消息的传输格式取决于流的安全状态：

- 当流处于**安全状态**时，IDE Fail消息必须作为IDE TLP传输
- 当流处于**非安全状态**时，IDE Fail消息必须作为非IDE TLP传输

这一规则确保了错误处理机制本身不会引入额外的安全风险。

### 3.3 TLP聚合限制

PCIe 6.0支持IDE TLP聚合以提高传输效率，但设置了严格限制：

- 聚合只能在同一流和子流内的TLP之间进行
- 数据载荷总和不得超过256 DW（双字）
- 聚合模式受相应字段控制
- 允许在聚合单元之间传输不属于该子流的其他TLP

这些限制确保了聚合操作不会破坏流的安全边界和传输可靠性。

## 4. 错误处理与恢复机制

### 4.1 毒化TLP与PCRC校验失败处理

当最终PCI Express目的地接收到毒化TLP或发生PCRC校验失败的IDE TLP时，处理方式取决于错误严重性和接收方的处理能力：

```mermaid
flowchart TD
    A[Receive Poisoned TLP or<br>IDE TLP with PCRC Check Failed] --> B{Severity &<br>Receiver Capability};
    B --> C[Non-fatal severity &<br>Receiver can continue operation];
    B --> D[Fatal severity or<br>Receiver cannot continue];
    C --> E[Handle as Advisory Non-Fatal Error];
    D --> F[Handle as Uncorrectable Error];
    
    subgraph ExampleScenarios
        G[Poisoned Memory Read Completion<br>received by Requester] --> H{Handling method};
        H --> I[Propagate poison internally<br>or handle like UR/CA Status];
        H --> J[Cannot handle without<br>affecting operation];
        I --> K[Signal ERR_COR if enabled];
        J --> L[Signal ERR_NONFATAL if enabled];
    end
```

例如，请求方接收到毒化的内存读完成TLP时，如果选择像处理UR/CA状态完成那样处理错误或以内部传播毒化数据的方式处理，且配置允许，应发出ERR_COR信号；如果无法以允许继续运行的方式处理毒化，则应发出ERR_NONFATAL信号。

### 4.2 ECRC处理规则

对于非IDE TLP，ECRC的处理遵循以下规则：

- 在无需FM/NFM转换时，交换机必须透传ECRC
- 需要转换时，必须重新计算ECRC
- 这种设计确保了CRC校验与传输路径的一致性

### 4.3 根端口错误处理架构

根端口的错误处理由高级错误报告（AER）和RP PIO错误控制共同管理。对于畸形TLP等错误，处理方式由相关的AER掩码和严重性位配置决定：

- 如果配置为不可纠正错误，则按严重错误处理
- 如果配置为建议性非致命错误，则按可恢复错误处理
- 如果错误被掩码，则不进行特殊处理

这种灵活的配置机制允许系统设计者根据具体应用场景调整错误处理策略。

## 5. 实践应用与设计考量

### 5.1 默认流分配策略

对于未与任何流关联的TLP，必须设置默认流位。发送器可以通过实现特定的方式选择TLP的流关联方式。例如，发送器可以将由一个或多个内部功能发起的**所有内存请求**与特定的选择性IDE流关联，特别是在已知合作伙伴端口是根端口且该内部功能发起的所有请求都以系统内存为目标时。

### 5.2 错误处理策略选择

系统设计者需要根据应用场景选择合适的错误处理策略：

- 对于要求高可用性的系统，可以配置更多错误为建议性非致命错误
- 对于要求数据绝对正确的系统，则应将关键错误配置为不可纠正错误
- 在可能导致静默数据损坏的场景中，必须按不可纠正错误处理

### 5.3 性能与可靠性的平衡

PCIe 6.0的TLP机制在设计上充分考虑了性能与可靠性的平衡：

- IDE加密提供了安全性，但增加了计算开销
- TLP聚合提高了效率，但受到安全限制
- 错误处理机制提供了灵活性，但需要合理配置

## 6. 总结

PCIe 6.0在TLP设计上的创新使其能够满足现代计算系统对带宽、安全性和可靠性的综合要求。通过端到端前缀支持、选择性IDE流、增强的错误处理机制等功能，PCIe 6.0在将传输速率提升至64 GT/s的同时，确保了数据完整性和系统可靠性。

对于硬件设计和系统开发人员而言，深入理解TLP的类型结构、前缀处理规则、IDE机制和错误处理体系，对于设计高性能、高可靠的PCIe 6.0系统至关重要。规范中提供的灵活配置选项允许根据具体应用需求优化系统行为，在性能、安全和可靠性之间找到最佳平衡点。

随着计算需求的持续增长，PCIe技术将继续演进，但对数据可靠性和完整性的基础要求将始终保持不变。PCIe 6.0的TLP机制为未来技术发展奠定了坚实基础，同时也为现有系统提供了向更高性能平滑过渡的路径。