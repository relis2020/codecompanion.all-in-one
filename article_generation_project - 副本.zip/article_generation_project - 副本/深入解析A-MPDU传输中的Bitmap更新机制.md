# 深入解析A-MPDU传输中的Bitmap更新机制

## 引言

在现代无线局域网（WLAN）技术中，为了提升数据传输效率，802.11协议引入了A-MPDU（Aggregated MAC Protocol Data Unit）聚合帧机制。A-MPDU允许将多个MPDU聚合到一个物理层帧中进行传输，显著减少了协议开销和传输延迟。在这一机制中，**bitmap**作为关键的数据结构，负责记录每个MPDU的确认状态，直接影响传输的可靠性和效率。本文将深入探讨A-MPDU传输中bitmap的更新机制，涵盖同步过程、状态维护、NDP BlockAck处理等核心内容，帮助读者全面理解这一关键技术。

## A-MPDU与Bitmap基础

### A-MPDU概述
A-MPDU是802.11n及后续标准中引入的帧聚合技术，它通过将多个MPDU封装到一个PHY帧中，减少了单个MPDU传输所需的 preamble、ACK等开销。每个A-MPDU由多个子帧（subframes）组成，每个子帧包含一个MPDU及其CRC校验。接收端需要对每个MPDU进行独立确认，这就需要一种高效的确认机制——bitmap应运而生。

### Bitmap的作用与结构
Bitmap是一个二进制位图，每个位对应一个MPDU的确认状态：1表示成功接收，0表示未接收或接收失败。其长度由协议协商的窗口大小（WinSize）决定，通常为64或256位。Bitmap的核心作用是实现**选择性重传**：发送端仅需重传未被确认的MPDU，而非整个A-MPDU，从而大幅提升带宽利用率。

## Bitmap更新的关键流程

### 1. 参数同步与初始化
在A-MPDU传输开始前，发送端（Originator）必须与接收端（Recipient）完成参数同步。根据802.11协议规范，同步涉及以下关键参数：
- **SSN（Starting Sequence Number）**：当前传输窗口的起始序列号。
- **WinStart_R**：接收端的窗口起始位置。
- **WinStart_B**：bitmap的起始偏移量。

同步可通过两种方式触发：
- 发送一个普通的MPDU帧，依赖ACK帧确认同步。
- 直接发送BlockAckReq帧，通过BlockAck帧响应完成同步。

这一步骤确保了双方对序列号范围和bitmap窗口的理解一致，是后续可靠传输的基础。

### 2. BlockAck帧的交互与解析
接收端在成功解聚合A-MPDU后，会生成一个BlockAck帧，其中包含bitmap字段。发送端收到BlockAck帧后，按以下流程解析并更新本地状态：
- 提取bitmap字段，逐位检查每个MPDU的确认状态。
- 根据序列号范围（SSN至WinStart_O + WinSize_B）验证bitmap的有效性。
- 对于bitmap中标记为1且序列号在有效范围内的MPDU，将其状态更新为“已确认”。
- 确保所有前置MPDU（从MPDU_SN起始且Start of MSDU子字段为1）的状态一致性，避免因分段传输导致的状态冲突。

### 3. 状态维护与缓冲区管理
Bitmap的更新直接关联到发送端的缓冲区管理。仅当MPDU被确认为成功后，发送端方可释放相应的传输缓冲区。这一机制避免了数据丢失，同时优化了内存使用。对于未确认的MPDU，发送端会将其保留在重传队列中，并根据协议策略（如重传次数限制）决定是否丢弃或重新传输。

## 特殊场景下的Bitmap处理

### NDP BlockAck的bitmap保护
NDP（Null Data Packet）BlockAck是一种高效但bitmap容量有限的确认帧，主要分为NDP_1M（8位bitmap）和NDP_2M（16位bitmap）两种类型。由于其bitmap字段尺寸较小，仅能确认有限数量的连续片段。为了增强bitmap的可靠性，802.11协议引入了异或编码保护机制：

- 对于NDP_1M BlockAck：`[B3:B10] = XOR([B3:B10],[B17:B24])`
- 对于NDP_2M BlockAck：`[B3:B18] = XOR([B3:B18],[B21:B36])`

发送端在传输前对bitmap进行编码，接收端采用相同的流程解码。这一机制显著提升了bitmap在噪声环境下的抗干扰能力。

### 部分状态操作中的动态bitmap创建
在某些场景下（如临时记录不存在），接收端需根据BlockAckReq帧中的SSN动态创建窗口参数和bitmap。具体步骤包括：
1. 设置WinStart_R = SSN。
2. 计算WinEnd_R = WinStart_R + WinSize - 1。
3. 根据窗口大小创建对应长度的bitmap。
这一机制确保了即使在状态不完整的情况下，双方也能保持同步。

## 性能优化与最佳实践

### 窗口大小的影响
窗口大小（WinSize）直接影响bitmap的效率和可靠性。较大的窗口允许更多MPDU聚合，提升吞吐量，但增加了bitmap的传输开销和错误率。实践中需根据网络条件（如信噪比、延迟）动态调整窗口大小。

### 错误处理与重传策略
Bitmap更新机制与重传策略紧密耦合。发送端应实现智能重传算法，例如：
- 基于历史数据的动态重传阈值调整。
- 优先重传高优先级MPDU。
- 结合信道状态选择重传时机。

### 跨协议兼容性
随着Wi-Fi标准的演进（如802.11ac/ax/be），bitmap机制也在不断优化。例如，802.11ax引入了多用户BlockAck，进一步扩展了bitmap的应用场景。开发者在实现时需确保向后兼容性，同时利用新特性提升性能。

## 总结

Bitmap更新是A-MPDU传输中的核心技术，其正确性和效率直接决定了无线网络的吞吐量和可靠性。本文详细分析了bitmap的更新流程，包括参数同步、BlockAck解析、状态维护以及特殊场景下的处理机制。通过深入理解这些细节，开发者可以更好地优化传输性能，提升用户体验。未来，随着Wi-Fi技术的持续演进，bitmap机制仍将是高效数据传输的关键支柱之一。

---

**参考文献**：  
IEEE Std 802.11-2020, IEEE Standard for Information Technology—Telecommunications and Information Exchange between Systems—Local and Metropolitan Area Networks—Specific Requirements.