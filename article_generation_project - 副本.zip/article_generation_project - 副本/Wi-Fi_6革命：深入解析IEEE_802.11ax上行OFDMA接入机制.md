# Wi-Fi 6革命：深入解析IEEE 802.11ax上行OFDMA接入机制

## 引言

随着无线网络设备数量的爆炸式增长和新兴应用对带宽需求的不断提升，传统Wi-Fi技术面临着严峻的挑战。IEEE 802.11ax标准，即**Wi-Fi 6**，作为下一代无线局域网技术，引入了一系列创新特性来提升网络效率和性能。其中，**上行正交频分多址接入（UL-OFDMA）** 机制作为关键创新之一，彻底改变了上行数据传输的方式。本文将深入解析UL-OFDMA的工作原理，重点关注其信道接入机制、传输过程和确认机制，为读者提供全面而深入的技术视角。

UL-OFDMA通过允许接入点（AP）同时调度多个站点（STA）在不同的资源单元（RU）上并行传输，显著提高了频谱利用率和上行链路效率。这种集中式调度机制不仅优化了资源分配，还为高密度部署场景提供了更好的支持。

## UL-OFDMA技术架构概述

### 系统架构基础

UL-OFDMA建立在Wi-Fi 6的物理层和MAC层增强功能之上。其核心思想是将可用频谱划分为多个较小的资源单元（RU），每个RU可以分配给不同的STA进行并行传输。这种频分复用方式与传统Wi-Fi的竞争式接入形成了鲜明对比。

系统架构中的关键参与者包括：
- **HE AP（高效率接入点）**：负责集中调度和资源分配
- **HE STA（高效率站点）**：按照AP的调度指示进行上行传输
- **Trigger Frame（触发帧）**：作为调度指令的核心载体

### 物理层增强特性

Wi-Fi 6物理层引入了多项改进来支持UL-OFDMA。HE TB PPDU（高效率触发基物理层协议数据单元）格式专门设计用于上行OFDMA传输，包含HE-SIG-A字段用于传输关键参数信息。这些增强使得多个STA能够精确同步并在指定RU上进行并行传输。

## 信道接入与调度机制

### Trigger Frame的核心作用

Trigger Frame是UL-OFDMA调度机制的核心。AP通过发送Trigger Frame来指示STA何时、在哪个RU上、以及如何使用何种参数进行上行传输。Trigger Frame包含两个主要部分：

**Common Info字段**：包含适用于所有被调度STA的公共信息
- **UL BW子字段**：指示PPDU的带宽
- **UL Length和PE Disambiguity子字段**：共同指示默认分组扩展（PE）持续时间
- **UL Spatial Reuse子字段**：以dBm为单位设置空间复用参数

**User Info字段**：包含针对每个STA的特定调度信息
- **RU Allocation子字段**：指定分配的资源单元
- **MCS设置**：指定调制编码方案
- **目标接收功率指示**：确保接收信号质量

### 空间复用机制

UL Spatial Reuse子字段的处理体现了Wi-Fi 6在干扰管理方面的进步。该值的确定基于Trigger帧中UL Target Receive Power子字段指示的预期接收信号功率，减去对应最高HE-MCS的最小SNR值（以实现≤10% PER），并考虑适当的安全余量。

当AP支持`dot11HEPSROptionImplemented`功能时，可通过选择Table 27-23中"Meaning"列数值最高的行来确定UL Spatial Reuse子字段的值，甚至可以设置为`PSR_DISALLOW`以完全禁止空间复用。`TX_PWR_AP`表示在包含Trigger帧的PSRR PPDU传输过程中，所有天线连接器上针对相应子信道的总功率（以dBm为单位）。

### 随机接入支持

除了调度接入外，UL-OFDMA还支持随机接入机制。如参考信息所示，"An HE AP may allocate a contiguous set of RUs for random access by setting the Number Of RA-RU subfield in the User Info field of the Trigger frame to a value greater than 1." 这种设计为未关联STA或突发流量提供了灵活的接入机会。

## 传输过程详解

### HE TB PPDU的构建与传输

当STA收到Trigger Frame后，需要按照指定参数构建HE TB PPDU。传输过程涉及多个关键步骤：

1. **RU映射**：User Info字段顺序与RU位置映射直接相关，确保多个STA的上行资源分配在频域上的有序性和效率

2. **功率控制**：STA根据Trigger Frame中的目标RSSI指示调整发射功率，确保AP接收到的信号强度在理想范围内

3. **时间同步**：所有被调度的STA必须精确同步开始传输，这是通过Trigger Frame的时间参考和SIFS间隔实现的

### 多用户传输的协调

UL-OFDMA的一个关键优势是能够协调多个STA的并行传输。AP通过精心设计的调度算法，考虑各STA的信道条件、业务需求和QoS要求，优化RU分配和传输参数。

传输参数包括：
- **MCS选择**：基于信道质量指示（CQI）反馈
- **RU大小分配**：根据数据量和信道条件动态调整
- **HE-LTF模式**：优化信道估计性能

## 确认与应答机制

### Multi-STA BlockAck框架

UL-OFDMA采用高效的Multi-STA BlockAck机制进行确认。如参考信息所述："An HE AP that receives, prior to association, an A-MPDU that includes one tagged MPDU that is a Management frame soliciting an acknowledgment but does not include any other MPDUs may generate a Multi-STA BlockAck frame..."

确认机制要求AP在SIFS间隔内立即回复Multi-STA BlockAck帧，确保传输效率。这种设计显著减少了传统逐个确认带来的开销。

### 确认上下文处理

Multi-STA BlockAck帧需要处理复杂的确认上下文。如标准中详细定义的，不同场景下的确认处理规则各不相同：
- 对于包含管理帧的A-MPDU
- 对于包含QoS数据帧的传输
- 预关联状态下的特殊处理规则

### 错误处理与重传机制

当传输失败时，UL-OFDMA提供了灵活的重传机制。AP可以通过后续的Trigger Frame调度重传，并根据需要调整传输参数以提高成功率。

## 性能优化与实现考虑

### 资源分配策略

有效的RU分配策略对UL-OFDMA性能至关重要。AP需要综合考虑多种因素：
- STA的信道质量指示
- 业务负载和QoS需求
- 公平性和效率的平衡
- 干扰状况和空间复用机会

### 功率控制优化

精确的功率控制不仅影响能效，还关系到空间复用的效果。AP通过Target RSSI指示和STA的实际发射功率反馈，实现精细的功率管理。

### 与传统设备的共存

Wi-Fi 6网络需要与传统设备共存。UL-OFDMA设计考虑了后向兼容性，确保混合网络环境下的稳定运行。

## 实际应用与部署考虑

### 高密度场景优化

UL-OFDMA特别适合高密度部署场景，如体育馆、机场、大型会议室等。通过精细的调度和资源分配，显著提升上行链路容量。

### 物联网应用支持

对于物联网设备，UL-OFDMA提供了高效的上行传输机制。小数据包的频繁传输可以通过适当的RU分配和调度得到优化。

### 实时应用性能

视频会议、在线游戏等实时应用对上行链路有严格要求。UL-OFDMA的调度机制可以优先保障这些应用的QoS需求。

## 总结

IEEE 802.11ax中的UL-OFDMA机制代表了Wi-Fi技术的重要演进。通过集中调度、精细资源分配和高效确认机制，显著提升了上行链路性能和频谱效率。Trigger Frame作为调度核心，承载了丰富的控制信息，使得AP能够智能地管理多用户传输。

随着Wi-Fi 6技术的广泛部署，UL-OFDMA将在提升用户体验、支持新兴应用方面发挥关键作用。未来的演进可能会进一步优化调度算法、增强干扰管理能力，并更好地支持多样化的应用需求。

理解UL-OFDMA的详细工作机制对于网络规划、优化和故障排查都具有重要意义。随着技术的发展和标准的演进，这一领域仍有许多值得深入探索的方向。


## 参考资料

- 26.5.2.5 UL MU CS mechanism - For a non AP STA that is solic......IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 26.5.4 UL OFDMA-based random access (UORA) (来源: 11ax.suffix)
- 26.5.2.2.5 AP access procedures for UL MU operation - The AP shall follow the EDCA p......IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 9.3.1.22.5 MU-RTS Trigger frame format - The Trigger Dependent Common I......IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 9.3.1.22.2 Basic Trigger frame format - The Trigger Dependent Common I......IEEE Std 80211ax 2021 IEEE Sta... (来源: 11ax.suffix)
- 26.5.2.5 UL MU CS mechanism - The RA of the Trigger frame is... (来源: 11ax.suffix)
- 26.5.2.3.3 TXVECTOR parameters for HE TB PPDU response to Trigger frame - IEEE Std 80211ax 2021IEEE Stan... (来源: 11ax.suffix)
- 9.3.1.22 Trigger frame format (来源: 11ax.suffix)
- 27.3.2.6 Resource allocation for an HE TB PPDU - UL MU transmissions are preced......The Trigger frame indicates wh... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - e If the HE STA supports acken......f If the... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - The received PSDU bits are ass... (来源: 11ax.suffix)
- 26.4.2 Acknowledgment context in a Multi-STA BlockAck frame - An HE AP that receives prior t... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - An HE AP may allocate a contig... (来源: 11ax.suffix)
- 10.25 Block acknowledgment (block ack) - If an HE STA transmits an HE T......In order to provide improved N... (来源: 11ax.suffix)
- 10.2.4a Triggered uplink access (TUA) - BlockAckReq and BlockAck frame......A non AP HE STA supports trigg... (来源: 11ax.suffix)
- 26.5.2.2.4 Allowed settings of the Trigger frame fields and TRS Control subfield - The UL Length subfield and the... (来源: 11ax.suffix)
- 26.5.2.2.4 Allowed settings of the Trigger frame fields and TRS Control subfield - The UL Length subfield in the ... (来源: 11ax.suffix)
- 10.3.2.13.3 Acknowledgment procedure for UL MU transmission - An AP that receives frames fro... (来源: qa_data_mac2024.new.suffix)
- 26.5.2.3 Non-AP STA behavior for UL MU operation (来源: 11ax.suffix)
- 9.3.1.22.1 General - tabletrtdTrigger Type subfield......The UL Length subfield of the ... (来源: 11ax.suffix)
- 26.5.2.2.4 Allowed settings of the Trigger frame fields and TRS Control subfield - An AP that transmits a Trigger......The AP shall set the UL Leng... (来源: 11ax.suffix)
- 9.3.1.22.5 MU-RTS Trigger frame format - The UL Length GI And HE LTF Ty......The RU Allocation subfield in ... (来源: 11ax.suffix)
- 10.3.2.13.3 Acknowledgment procedure for UL MU transmission - When an AP transmits an immedi... (来源: qa_data_mac2024.new.suffix)
- 26.5.2.2.3 Padding for a triggering frame - An AP transmitting a Trigger f... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - If an associated non AP STA th... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - A non AP STA that responds to ... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - A non AP STA that responds to ......NOTE 6Th... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - A non AP STA that receives a F......An unass... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - A non AP HE STA that sends a f... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - A non AP HE STA shall determin... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - NmathrmNONHTDULOFDMDatamathrmT......In a non... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - A non AP STA may set dot11HEUP......where (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - A non AP HE STA that receives ......IEEE Std... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - A non AP HE STA may consider a......NOTE 3A ... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology—Local and Metropolitan Area Netwo... - An HE beamformee that is a non... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - TRIGGERFRAME for Trigger frame... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - a The Trigger frame addressed ......A non AP... (来源: 11ax.suffix)
- 27.3.15 Transmit requirements for PPDUs sent in response to a triggering frame (来源: 11ax.suffix)
- 26.5.2.3.3 TXVECTOR parameters for HE TB PPDU response to Trigger frame - The LLENGTH parameter is set t... (来源: 11ax.suffix)
- 26.5.2.3.3 TXVECTOR parameters for HE TB PPDU response to Trigger frame - IEEE Std 80211ax 2021 IEEE Sta......The HE TBPEDISAMBIGUITY parame... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - A Trigger frame transmitted du......The TWT ... (来源: 11ax.suffix)
- IEEE Std 802.11ax-2021 IEEE Standard for Information Technology--Local and Metropolitan Area Netw... - NOTE 7 A Trigger frame identif......NOTE 8 O... (来源: 11ax.suffix)
- 26.10.3.4 UL Spatial Reuse subfield of Trigger frame - is a value in dBm for that  20... (来源: 11ax.suffix)
- 26.10.3.4 UL Spatial Reuse subfield of Trigger frame - An AP with dot11HEPSROptionImp... (来源: 11ax.suffix)
- 26.10.3.4 UL Spatial Reuse subfield of Trigger frame - TX PWRAP  is the total power a......Acceptable Receiver Interferen... (来源: 11ax.suffix)
- 26.10.3.4 UL Spatial Reuse subfield of Trigger frame - An AP with dot11HEPSROptionImp......where (来源: 11ax.suffix)
- 26.5.2.2.4 Allowed settings of the Trigger frame fields and TRS Control subfield - An example of User Info field ......Figure 264Example of User In... (来源: 11ax.suffix)
- 9.3.1.22.1 General - IEEE Std 80211ax 2021 IEEE Sta......Table 929cTrigger Type subfiel... (来源: 11ax.suffix)
- 9.3.1.22.1 General - The UL HE SIG A2 Reserved subf......The User Info List field conta... (来源: 11ax.suffix)
