# 深入解析Bitmap更新机制：从序列号索引到状态同步

## 引言

在现代网络通信和数据传输系统中，bitmap（位图）作为一种高效的数据结构，被广泛应用于状态记录、资源管理和信息同步等场景。从无线网络的帧确认机制到接入点的缓存状态指示，bitmap通过简单的二进制位设置实现了复杂的状态管理功能。本文将深入探讨bitmap的更新机制，分析不同应用场景下的更新规则和实现原理，帮助开发者更好地理解和应用这一重要数据结构。

## Bitmap基础概念与索引机制

### 基本结构与索引原理

Bitmap本质上是一个二进制位数组，每个比特位代表某种特定状态或信息。在大多数网络协议实现中，bitmap采用**序列号索引机制**进行组织和管理。具体而言：

- bitmap与一个12位无符号整数的起始序列号$WinStart_{R}$相关联
- $WinStart_{R}$代表bitmap中最低的序列号位置
- 每个比特位对应一个特定的序列号，用于指示该序列号对应的数据帧是否已被成功接收

当接收到的数据帧序列号$SN$满足$WinStart_{R}\leq SN\leq WinEnd_{R}$时，bitmap中相应序列号位置的比特位会被设置为1，表示该数据帧已成功接收。

### 窗口大小与范围管理

Bitmap的窗口大小$WinSize_R$决定了其能够覆盖的序列号范围。在实际实现中：

```c
// 伪代码示例：bitmap初始化
uint16_t WinStart_R;    // 窗口起始序列号
uint16_t WinEnd_R;      // 窗口结束序列号
uint16_t WinSize_R;     // 窗口大小
uint8_t bitmap[256];    // bitmap存储数组

// 初始化bitmap
void init_bitmap(uint16_t start_seq) {
    WinStart_R = start_seq;
    WinEnd_R = start_seq + WinSize_R - 1;
    memset(bitmap, 0, sizeof(bitmap)); // 所有位初始化为0
}
```

## Bitmap更新场景与规则

### 数据帧接收时的更新

在部分状态操作的HT-immediate块确认协议中，bitmap的更新遵循特定规则：

1. **新建临时记录场景**
   - 当接收到与特定协议相关的数据帧时，如果不存在该协议的临时记录
   - 创建临时块确认记录，根据序列号确定窗口起始和结束位置
   - 初始化bitmap，所有比特位设置为0
   - 将对应接收数据帧序列号SN的比特位置1

2. **已有记录更新场景**
   - 如果已存在该协议的临时记录
   - 按照全状态协议中描述的方式修改临时块确认记录
   - 更新规则遵循10.25.6.3节中的确认记录更新规范

### 序列号超出窗口范围的处理

当接收到的数据帧序列号超出当前接收窗口但仍在有效范围内时，需要进行特殊的bitmap重置操作：

```c
// 处理序列号超出当前窗口的情况
void handle_out_of_window(uint16_t new_SN) {
    if (WinEnd_R < new_SN && new_SN < WinStart_R + 2048) {
        // 重置序列号从WinEnd_R + 1到new_SN - 1范围内的比特位为0
        reset_bitmap_range(WinEnd_R + 1, new_SN - 1);
        
        // 更新接收窗口位置
        update_window_position(new_SN);
    }
}
```

这种机制确保了bitmap能够正确处理序列号回绕和窗口滑动的情况，维护了数据接收状态的一致性。

## 特定应用场景中的Bitmap更新

### 广播元素Bitmap更新

在MCCAOP（Mesh协调信道接入机会）Advertisement机制中：

- Advertisement Elements Bitmap字段的比特位设置取决于MCCAOP Advertisement元素的存在性
- 比特位i被设置为1的条件：
  - 存在一个MCCAOP Advertisement元素
  - 该元素的MCCAOP Advertisement Element Index子字段值等于i
  - 该元素是当前MCCAOP advertisement set表示的一部分

**同步机制特点**：
- 如果接收方bitmap中某位的值与发送方相应位的值相同
- 表示该索引对应的Advertisement element是最新的
- 无需进行更新操作，减少了不必要的通信开销

### 集群偏移Bitmap更新

在无线网络集群环境中，Available Cluster Offset Bitmap的更新通过特定的信令机制实现：

1. **更新触发条件**：成员AP或PCP接收Cluster Switch Announcement元素
2. **传输方式**：通过DMG Beacon帧进行广播传输
3. **信息内容**：包含集群信息及其集群切换决定
4. **更新效果**：使集群成员能够同步集群状态信息

这种机制确保了分布式环境中各个节点状态的一致性，提高了网络的可靠性和协调性。

### 页面Bitmap与电源管理

在WLAN电源管理机制中，Page Bitmap发挥着重要作用：

#### 比特值为0的含义
- 表示AP没有为对应块内的关联标识符（AID）所对应的STA缓存任何数据
- 这些STA在确认没有缓存的组寻址数据后可以立即返回到休眠状态
- 或者在DTIM信标指示下接收完缓存的广播/组数据后进入休眠

#### 比特值为1的含义
- 表示AP至少为对应块中的一个或多个STA缓存了数据
- 相关STA需要保持唤醒状态以接收数据
- STA需要计算页面分片长度和对应的TIM（流量指示映射）

```c
// STA电源管理决策逻辑
void sta_power_management_decision(uint8_t page_bitmap_value) {
    if (page_bitmap_value == 0) {
        // 无缓存数据，可进入休眠
        enter_sleep_mode();
    } else {
        // 有缓存数据，保持唤醒
        stay_awake();
        calculate_page_slice_parameters();
        process_tim_information();
    }
}
```

## 物理层Bitmap应用

### 信道状态评估

PHY-CCA.indication原语中的per20bitmap参数提供了细粒度的信道状态信息：

- **功能**：指示组成操作信道宽度的每个20MHz子信道的忙闲状态
- **格式**：以位图形式提供每个20MHz子信道的CCA（空闲信道评估）状态
- **应用**：使MAC层能够了解详细的信道占用情况，优化信道选择策略

这种机制在现代宽带无线通信中尤为重要，特别是在信道绑定和动态频谱访问场景中。

## Bitmap更新最佳实践

### 性能优化策略

1. **批量更新操作**
   - 对连续序列号范围的比特位更新采用批量操作
   - 减少内存访问次数，提高处理效率

2. **位操作优化**
   - 使用位掩码和移位操作进行高效比特位访问
   - 利用处理器提供的位操作指令集

```c
// 高效的bitmap位设置示例
void set_bit(uint16_t seq_num) {
    uint16_t index = (seq_num - WinStart_R) / 8;
    uint8_t bit_position = (seq_num - WinStart_R) % 8;
    bitmap[index] |= (1 << bit_position);
}
```

### 错误处理与恢复

1. **序列号异常检测**
   - 实现序列号有效性验证机制
   - 处理序列号回绕和溢出情况

2. **状态同步机制**
   - 定期校验bitmap与实际状态的的一致性
   - 实现bitmap重建和恢复机制

## 总结

Bitmap作为一种高效的状态管理数据结构，在网络通信系统中发挥着至关重要的作用。通过序列号索引机制、灵活的更新规则和多种应用场景的适配，bitmap实现了复杂状态信息的简洁表示和高效同步。

从数据帧接收到电源管理，从广播元素同步到物理层信道状态评估，bitmap的更新机制体现了网络协议设计的精巧和高效。深入理解这些机制不仅有助于网络协议的实现和优化，也为处理类似状态管理问题提供了有价值的参考模式。

随着网络技术的发展，bitmap的应用场景和更新机制将继续演进，但其核心思想——用最小化的数据表示最大化的信息——将始终是高效系统设计的重要原则。