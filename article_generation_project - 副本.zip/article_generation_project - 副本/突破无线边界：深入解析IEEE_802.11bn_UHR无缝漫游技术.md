# 突破无线边界：深入解析IEEE 802.11bn UHR无缝漫游技术

> 在当今高度移动化的世界中，你是否曾经历过视频会议时因Wi-Fi切换而卡顿？或是在移动办公中遭遇网络中断的困扰？这些痛点正是IEEE 802.11bn Ultra High Reliability（UHR）标准致力于解决的核心问题。本文将带您深入探索这一革命性技术的内部机制。

传统的无线漫游技术需要设备与新的接入点重新建立关联，导致通信中断和体验下降。IEEE 802.11bn UHR标准引入的**无缝移动域（Seamless Mobility Domain, SMD）**技术彻底改变了这一现状，使多链路设备（MLD）能够在不同接入点间切换而无需重新关联，真正实现了"零感知"漫游体验。

## 一、技术本质与架构基础

### 1.1 什么是SMD无缝漫游？

SMD BSS Transition是一种基于MAC层协议操作的先进漫游机制，允许非AP MLD在同一个SMD内从一个AP MLD切换到另一个AP MLD，同时保持终端始终处于关联状态（State 4）并保留完整的传输上下文。这种机制通过消除重新关联过程，将漫游中断时间降至最低。

### 1.2 安全架构设计

SMD的安全基础建立在统一的密钥管理体系上。每个SMD由唯一的SMD标识符（通过SMD Information element定义）进行标识，支持单个PMKSA（Pairwise Master Key Security Association）和PTKSA（Pairwise Transient Key Security Association）的建立。

在初始关联阶段，非AP MLD通过SMD标识符与SMD移动实体（SMD-ME）协商SMD级别的PTKSA，为整个漫游过程提供统一的安全上下文。系统支持两种安全模式：Per-SMD PTK模式和Per-AP MLD PTK模式，前者在整个SMD内使用相同的PTK，而后者需要在切换到目标AP MLD时重新派生PTK。

## 二、技术实现机制详解

### 2.1 发现与准备阶段

漫游过程始于候选AP MLD的发现。非AP MLD可以通过多种机制发现邻近的AP MLD和它们的SMD BSS转换支持能力：

- **主动扫描机制**：基于11.1.4.3.2（非DMG STA的主动扫描程序）和35.3.4.2（多链路探测请求和响应的使用）
- **BSS转换管理框架**：遵循11.21.7（BSS转换管理）和35.3.23（MLD的BSS转换管理）规范
- **邻居报告框架**：依据11.10.10（邻居报告的使用）标准

准备阶段的核心是ST Preparation Request帧的交换，该帧包含目标AP MLD地址及Per-STA Profile子元素。当前AP MLD负责将所有已建立的SCS（Stream Classification Service）和MSCS（Multi-Stream Classification Service）描述符转移至目标AP MLD。

目标AP MLD基于自身资源可用性决定接受或拒绝这些服务流。在此过程中，非AP MLD需要在目标链路上保持省电模式，遵循35.3.6.4规定的链路重配置流程。

### 2.2 执行与上下文转移

执行阶段提供两种路径选择：通过当前AP MLD或直接通过目标AP MLD。无论选择哪种路径，上下文转移都是确保无缝体验的关键环节。

需要转移的上下文包括：

- 块确认参数（Block Ack parameters）
- SN序列号（Sequence Number）
- 重复接收缓存（Duplicate Receive Buffer）
- 其他关键传输状态信息

根据37.14.8规范，上下文转移必须完整且准确。特别值得注意的是，如果非AP MLD请求当前AP MLD不传输现有DL块确认协议的下一SN，目标AP MLD需要将所有DL TID的SN重置为0，同时非AP MLD需要将每个具有块确认协议的DL TID的WinStartB初始化为0。

### 2.3 数据传输与引流机制

DLDrainTime机制负责管理下行数据引流过程。在当前AP MLD发送ST Execution Response确认后，它可以继续向非AP MLD发送数据帧，直到引流期结束或通过UHR Link Reconfiguration Notify帧提前终止。

当下行数据转发功能支持时，当前AP MLD可以转发需要重传的MSDU/A-MSDU数据帧。根据37.14.10规范，每个需要重传且在WinStarto和WinEndo范围内的数据帧可以携带以下信息：

- TID（Traffic Identifier）
- SN（Sequence Number）
- PN（Packet Number）

这种精细化的数据管理机制确保了数据传输的连续性和完整性。

## 三、关键帧结构与协议交互

### 3.1 UHR链路重配置帧

UHR Link Reconfiguration Request/Response帧是准备与执行阶段的核心通信机制，通过Type字段区分不同的操作类型。这些帧承载着漫游过程中所需的各种参数和状态信息。

### 3.2 执行响应帧的重要性

ST Execution Response帧包含关键的安全参数和其他必要信息，这些信息可能已在SMD BSS转换准备过程中由目标AP MLD提供给当前AP MLD。非AP MLD在收到状态值设置为SUCCESS的响应帧之前，不得向目标AP MLD发送Class 3帧。

## 四、技术优势与应用前景

IEEE 802.11bn UHR无缝漫游技术通过多链路协调与统一安全上下文，显著提升了高可靠性场景下的漫游效率。其技术优势主要体现在：

1. **极低中断时间**：消除重新关联过程，实现毫秒级切换
2. **完整上下文保持**：维持所有传输状态和安全上下文
3. **灵活路径选择**：支持通过当前或目标AP MLD两种执行路径
4. **精细化数据管理**：DLDrainTime和下行数据转发机制确保数据连续性

这一技术特别适用于对可靠性要求极高的应用场景，如工业物联网、自动驾驶、远程医疗和增强现实等。随着5G-Advanced和6G技术的发展，这种无缝漫游机制将成为未来无线网络的重要组成部分。

## 结语：迈向真正无缝的无线未来

IEEE 802.11bn UHR标准的无缝漫游技术代表了无线通信领域的一次重大飞跃。通过MAC层协议的创新设计，它成功解决了长期困扰移动用户的漫游中断问题。正如我们在本文中详细分析的，从统一安全架构到精细化的上下文转移机制，每一个技术细节都体现了对高可靠性和无缝体验的追求。

随着物联网和移动应用的快速发展，对无线网络可靠性的要求只会越来越高。IEEE 802.11bn UHR为我们描绘了一个真正无缝连接的未来图景，其中网络切换将变得如此平滑，以至于用户完全感知不到其存在。这不仅是技术的进步，更是用户体验的革命性提升。