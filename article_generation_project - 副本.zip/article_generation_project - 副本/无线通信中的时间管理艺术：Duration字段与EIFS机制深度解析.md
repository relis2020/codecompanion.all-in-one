# 无线通信中的时间管理艺术：Duration字段与EIFS机制深度解析

## 引言

在现代无线通信系统中，介质访问控制（MAC）层的时间同步与管理是保障网络高效运行的核心要素。其中，Duration/ID字段和扩展帧间间隔（EIFS）作为IEEE 802.11协议家族中的关键时间管理机制，共同构成了无线信道分配与错误恢复的基础架构。这些机制不仅影响着单个设备的通信效率，更直接关系到整个网络系统的吞吐量、延迟和可靠性。随着无线通信技术从传统802.11a/b/g发展到如今的Wi-Fi 6（802.11ax）乃至Wi-Fi 7（802.11be），这些时间管理机制也在不断演进，支持更复杂的物理层技术和更高效的帧聚合方案。本文将深入探讨这两个关键机制的实现原理、相互作用关系及其在实际应用中的技术细节。

## Duration/ID字段：信道时间预留的精确控制器

### 基本定义与功能定位

Duration/ID字段是MAC帧头部中的一个16位字段，其主要功能是通过网络分配向量（NAV）机制实现虚拟载波侦听。NAV本质上是一个计数器，在每个站点中指示信道将被占用的剩余时间，使站点能够避免在信道繁忙时进行传输尝试，从而减少冲突概率。

当Duration/ID字段的值小于32768时，它表示一个以微秒为单位的时间间隔，用于预留信道占用时间。这个时间计算包含了当前帧的传输时间、可能的应答帧间隔以及任何必要的帧间间隔。这种精确的时间预留机制使得多个站点能够协调共享无线信道，是实现分布式协调功能（DCF）的基础。

### 技术实现细节

Duration字段的计算涉及复杂的物理层参数考量。对于不同的物理层技术（如HR/DSSS、OFDM、HT、VHT、HE），传输时间（TXTIME）的计算方法各不相同。以传统的802.11a/g OFDM系统为例，传输时间计算需考虑前导码长度、信号字段传输时间以及数据部分的传输时间，其中数据部分传输时间又取决于OFDM符号长度和编码速率。

特别值得注意的是PS-Poll帧中的Duration字段设置。在节能模式下，站点发送PS-Poll帧向接入点请求缓存的帧时，其Duration字段值被设置为传输一个ACK帧加上一个短帧间间隔（SIFS）所需的时间。这个值需要根据数据速率选择规则计算，并向上取整至整数微秒，确保有足够的时间完成整个事务过程。

### 多技术适配与演进

随着无线技术的发展，Duration字段的处理也变得更加复杂。在802.11n引入的HT（高吞吐量）系统中，需要考虑帧聚合带来的影响；在802.11ac的VHT（极高吞吐量）系统中，多用户MIMO技术使得时间计算需考虑多个同时传输；而在最新的802.11ax HE（高效率）系统中，OFDMA技术的引入进一步增加了时间计算的复杂性，需要同时考虑多个资源单元的分配情况。

## EIFS：错误处理与恢复的安全卫士

### 基本概念与设计原理

扩展帧间间隔（EIFS）是802.11协议中用于错误接收后信道访问控制的一种特殊帧间间隔。当站点检测到帧传输错误时（通常通过CRC校验失败），它会启动EIFS计时器，在此期间避免发送任何数据，为可能的后续传输（如重传机制）提供足够的时间窗口。

EIFS的设计基于一个关键观察：当站点错误接收一个帧时，它无法确定这个帧的目的地是否是自已，也无法确定是否需要响应。因此，EIFS提供了一个保守的等待期，确保不会干扰可能存在的后续传输（如ACK帧），从而维持网络的稳定性。

### 计算模型与动态调整

EIFS的基础计算公式为：EIFS = aSIFSTime + AckTxTime + DIFS。其中，aSIFSTime是短帧间间隔时间，AckTxTime是基于最低强制速率或MCS（调制编码方案）的ACK帧传输时间，DIFS是分布式协调功能帧间间隔。

现代802.11实现中引入了动态EIFS调整机制（通过dot11DynamicEIFSActivated参数控制）。在这种机制下，如果触发EIFS的PPDU（物理层协议数据单元）包含14或32字节的MPDU（MAC协议数据单元），如ACK或BlockAck帧，则EIFS简化为等于DIFS，因为这些短帧不需要长时间的保护期。对于其他情况，系统会根据PPDU调制类型查表确定EstimatedAckTxTime，然后计算相应的EIFS值。

### 适用条件与例外情况

EIFS机制并非在所有错误情况下都适用。特别地，当使用帧聚合（A-MPDU）时，如果至少有一个MPDU被正确接收，则不触发EIFS，因为正确接收的帧可以提供足够的信息来确定信道状态。此外，在HE PPDU中，当TXOP_DURATION参数被明确指定而非设置为UNSPECIFIED时，EIFS机制也可能被绕过，因为明确的传输时长信息已经提供了足够的信道状态指示。

## 协同工作机制与性能影响

### NAV与EIFS的交互关系

Duration字段通过NAV机制间接影响EIFS的操作。当Duration字段设置的NAV计时器正在运行时，它表示信道已被预留，此时即使发生接收错误，EIFS机制也可能被NAV覆盖，因为信道状态已经通过NAV得到了明确指示。

这种交互关系体现了802.11协议中多层保护机制的设计哲学：NAV提供基于帧信息的主动信道预留，而EIFS提供基于错误检测的被动保护。两者相互补充，共同确保信道访问的有序性。

### 对网络性能的影响分析

合理地配置Duration字段和EIFS参数对网络性能至关重要。过长的Duration设置会导致信道利用率降低，因为过多的保护时间被预留但未被使用；而过短的Duration则可能引起冲突，导致重传和效率下降。

同样，EIFS的设置也需要在保护性和效率之间取得平衡。过长的EIFS会不必要地延长错误后的等待时间，降低网络吞吐量；而过短的EIFS则可能无法提供足够的保护，导致更多的冲突和错误。

在实际部署中，这些参数通常根据网络环境动态调整。在高密度部署场景中，可能需要更保守的设置以减少冲突；而在低干扰环境中，则可以采用更激进的参数以提高效率。

## 实际应用与配置考量

### 不同物理层技术的适配

在实际设备中，Duration字段和EIFS的实现需要适配不同的物理层技术。例如，在传统的802.11b DSSS系统中，时间计算基于芯片率和编码方式；而在802.11a/g OFDM系统中，则需要考虑OFDM符号长度和循环前缀等因素。

对于支持多物理层技术的设备，需要实现智能的适配机制，根据当前使用的物理层类型选择正确的计算方法。这种适配通常通过查表方式实现，表中存储了各种物理层模式下的参数和计算规则。

### 厂商实现差异与兼容性

虽然802.11标准定义了Duration和EIFS的基本行为，但不同厂商在具体实现上可能存在差异。这些差异可能体现在参数的计算方法、动态调整策略以及异常情况处理等方面。

在实际网络环境中，这种实现差异可能导致兼容性问题，特别是在多厂商设备混合部署的场景中。网络管理员需要了解这些潜在差异，并在必要时进行针对性配置，以确保网络的稳定运行。

### 调试与优化实践

对于网络管理员和工程师，理解这些时间管理机制对于网络调试和优化至关重要。通过监控NAV状态和EIFS触发情况，可以识别潜在的网络问题，如过高的错误率、不合理的参数设置或设备兼容性问题。

常用的优化策略包括：调整帧大小以减少传输时间、优化数据速率选择以降低错误概率、配置适当的TXOP参数以提高信道利用率等。这些优化需要基于对实际网络流量的详细分析和理解。

## 总结

Duration字段和EIFS作为802.11无线协议中关键的时间管理机制，共同构成了无线信道访问控制的基础框架。Duration字段通过NAV机制提供主动的信道预留，而EIFS则在错误情况下提供被动的保护机制，两者协同工作，确保了无线网络的高效稳定运行。

随着无线技术的不断发展，这些机制也在持续演进，以支持更高的吞吐量、更低的延迟和更复杂的应用场景。对于网络工程师和研究人员而言，深入理解这些机制的实现细节和交互关系，对于设计、部署和优化现代无线网络具有重要意义。

未来，随着新兴技术如Wi-Fi 7、毫米波通信和智能反射表面的发展，时间管理机制将面临新的挑战和机遇，需要进一步的研究和创新来满足日益增长的网络需求。


## 参考资料

- 10.6.1 Overview - 1634 for HR TXTIME calculation......The DurationID field in a fram... (来源: qa_data_mac2024.new.suffix)
- EIFS = aSIFSTime + AckTxTime + DIFS - When dot11DynamicEIFSActivated... (来源: qa_data_mac2024.new.suffix)
- EIFS = aSIFSTime + AckTxTime + DIFS - trtrtdHTtdtdBPSKtdtdAggregatio... (来源: qa_data_mac2024.new.suffix)
- EIFS = aSIFSTime + AckTxTime + DIFS - dtdBlockAcktdtdtdtd32tdtrtable (来源: qa_data_mac2024.new.suffix)
- 10.28.3 Duration/ID field processing - When the contents of a receive... (来源: qa_data_mac2024.new.suffix)
- EIFS = aSIFSTime + AckTxTime + DIFS - Figure 10 25 illustrates the r......mathrmTxSIFS  mathrmSIFS  math... (来源: qa_data_mac2024.new.suffix)
- EIFS = aSIFSTime + AckTxTime + DIFS - where AckTxTime is the time ex......When dot11DynamicEIFSAcctivate... (来源: qa_data_mac2024.new.suffix)
- EIFS = aSIFSTime + AckTxTime + DIFS - tabletrtdModulation of PPDU ca... (来源: qa_data_mac2024.new.suffix)
- EIFS = aSIFSTime + AckTxTime + DIFS - In a non DMG and non S1G STA w......Table 108Determination of the ... (来源: qa_data_mac2024.new.suffix)
- EIFS = aSIFSTime + AckTxTime + DIFS - mathrmTxPIFS  mathrmTxSIFS  ma......NOTE 3The tolerance for SIFS i... (来源: qa_data_mac2024.new.suffix)
- 10.3.2.3.1 General - The time interval between cert......The IFSs are as follows (来源: qa_data_mac2024.new.suffix)
- 10.3.2.3.7 EIFS - DIFS or AIFS as appropriate an......EIFS shall not be invoked for ... (来源: qa_data_mac2024.new.suffix)
- Change 10.3.2.3.7 as follows: - A DCF shall use EIFS before tr... (来源: 11ax.suffix)
- 10.3.2.3.7 EIFS - The EIFS and EIFS DIFSAIFSAC a... (来源: qa_data_mac2024.new.suffix)
- 10.3.2.3.7 EIFS - A DCF shall use EIFS before tr... (来源: qa_data_mac2024.new.suffix)
- 10.3.2.4 Setting and resetting the NAV - If there is a Duration field i... (来源: qa_data_mac2024.new.suffix)
- Change 10.3.2.3.7 as follows: - EIFS shall not be invoked for ... (来源: 11ax.suffix)
- 10.3.2.4 Setting and resetting the NAV (来源: 11ax.suffix)
- Change 10.3.2.3.7 as follows: - The EIFS and EIFS DIFSAIFSAC a... (来源: 11ax.suffix)
- 10.3.2.4 Setting and resetting the NAV - indication primitive is receiv... (来源: qa_data_mac2024.new.suffix)
