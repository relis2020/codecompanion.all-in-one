#ifndef SRAM_COMPILER_H
#define SRAM_COMPILER_H

#include <gdstk/gdstk.hpp>

/**
 * Create a configurable SRAM bitcell array
 * @param gds_file Input GDS file containing the cell library
 * @param rows Number of rows in the SRAM array
 * @param cols Number of columns in the SRAM array
 * @param output_file Output GDS file to save the generated SRAM array
 * @return gdstk::ErrorCode indicating success or failure
 */
gdstk::ErrorCode create_sram(const char *gds_file, const unsigned &rows,
                             const unsigned &cols, const char *output_file);

#endif // SRAM_COMPILER_H