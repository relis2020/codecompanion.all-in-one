#include <gdstk/gdstk.hpp>
#include <plog/Appenders/ColorConsoleAppender.h>
#include <plog/Formatters/TxtFormatter.h>
#include <plog/Init.h>
#include <plog/Log.h>

#include "sram_compiler.h"

int main(int argc, char **argv) {
  // Initialize plog
  static plog::ColorConsoleAppender<plog::TxtFormatter> consoleAppender;
  plog::init(plog::debug, &consoleAppender);

  if (argc < 5) {
    LOGE << "Usage: " << argv[0] << " <input_gds_file>"
         << "<num_rows> <num_cols> <output_gds_file>";
    return -1;
  }

  const char *input_gds_file = argv[1];
  const unsigned num_rows = std::stoul(argv[2]);
  const unsigned num_cols = std::stoul(argv[3]);
  const char *output_gds_file = argv[4];

  LOGI << "===========================================";
  LOGI << "|           ASAP7 SRAM Compiler.          |";
  LOGI << "|-----------------------------------------|";
  LOGI << "|  Author:      Shao-Chien Lu             |";
  LOGI << "|  Affiliation: Yuan Ze University        |";
  LOGI << "|  Email:       s1111534@mail.yzu.edu.tw  |";
  LOGI << "|  Version:     0.1 (2025)                |";
  LOGI << "===========================================";

  LOGD << "Input GDS file: " << input_gds_file;
  LOGD << "Number of rows: " << num_rows;
  LOGD << "Number of columns: " << num_cols;
  LOGD << "Output GDS file: " << output_gds_file;

  gdstk::ErrorCode result =
      create_sram(input_gds_file, num_rows, num_cols, output_gds_file);
  if (result != gdstk::ErrorCode::NoError) {
    LOGE << "SRAM creation failed with error code: " << (int)result;
    return -1;
  }
}
