#include "sram_compiler.h"

#include <gdstk/gdstk.hpp>
#include <plog/Log.h>

gdstk::ErrorCode create_sram(const char *gds_file, const unsigned &rows,
                             const unsigned &cols, const char *output_file) {
  // Read the cell library
  gdstk::ErrorCode error = gdstk::ErrorCode::NoError;
  gdstk::Library cell_lib = gdstk::read_gds(gds_file, 0, 1e-2, NULL, &error);
  if (error != gdstk::ErrorCode::NoError) {
    return error;
  }

  // Get the library unit and precision
  const double unit = cell_lib.unit;
  const double precision = cell_lib.precision;

  // Create the SRAM library
  const std::string lib_name =
      "sram_" + std::to_string(rows) + "x" + std::to_string(cols);
  gdstk::Library sram = {};
  sram.init(lib_name.c_str(), unit, precision);

  // Write gds file
  LOGD << "Writing output GDS file: " << output_file;
  error = sram.write_gds(output_file, 0, NULL);
  if (error != gdstk::ErrorCode::NoError) {
    return error;
  }

  // Without any errors
  return error;
}