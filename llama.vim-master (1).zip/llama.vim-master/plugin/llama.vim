call llama#init()
